Hello, and welcome to our engine!
On the User interface you will see two texts box.
On the first one please insert the directory of the corpus.
On the second text box please insert the directory you would like the information to be writtten.
If you want to use the Stemming option, please tick in the choosing box.
More options you can use:
1. Reset will remove all of the folders that were created.
2. Display the Terms-TF dictionary
3.Load the dictionary to the disk

Itai and Tomer