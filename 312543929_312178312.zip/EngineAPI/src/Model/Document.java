package Model;

public class Document {

    String docName;
    int maxTf;
    int uniqueTerms;

    /**
     * Constructor
     * @param docName
     * @param maxTf
     * @param uniqueTerms
     */
    public Document(String docName, int maxTf, int uniqueTerms){
        this.docName=docName;
        this.maxTf=maxTf;
        this.uniqueTerms=uniqueTerms;
    }

    @Override
    public String toString (){
        return docName+","+maxTf+","+uniqueTerms;
    }

}
