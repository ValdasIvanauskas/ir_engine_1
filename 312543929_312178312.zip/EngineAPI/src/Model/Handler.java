package Model;

import java.io.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class Handler extends Thread implements Runnable {

    private int numOfFolder; // represents the numbers of folders in the corpus
    String pathOfCorpus; //path of the corpus
    String pathOfPosting; // path for the posting files
    HashSet<String> stopWords; //holds the stop-words of the corpus
    private int toGo; //Shared resource for the threads
    private boolean isStemming; // stemming option on or not
    private ExecutorService executor;
    Indexer indexer;
    ReentrantLock lock1;
    ReentrantLock lock2;
    private long startTime;
    private long endTime;


    /**
     * Constructor
     * @param pathOfCorpus
     * @param pathOfPosting
     * @param isStemming
     * @throws FileNotFoundException
     */
    public Handler(String pathOfCorpus, String pathOfPosting, boolean isStemming) throws FileNotFoundException {

        this.pathOfCorpus = pathOfCorpus;
        this.pathOfPosting = pathOfPosting;
        File mainDir = new File(pathOfCorpus);
        String[] subDirs = mainDir.list();
        this.numOfFolder = subDirs.length;
        this.toGo = 0;
        executor = Executors.newFixedThreadPool(3);
        ReadFile tempReader = new ReadFile(pathOfCorpus);
        this.stopWords = tempReader.readStopWord();
        this.isStemming = isStemming;
        createFolders();
        indexer = new Indexer(this.pathOfPosting, this.pathOfCorpus + "\\documents", this.isStemming);
        lock1 = new ReentrantLock();
        lock2 = new ReentrantLock();

    }

    /**
     * The function sends back the indexer object
     * @return
     */
    public Indexer getIndexer(){
        return indexer;
    }


    /**
     * the function creates folders when the Stemming option is on
     */
    private void createFolders(){
        File theDir;
        if (isStemming) {
            theDir = new File(this.pathOfPosting + "/WithStem/");
            this.pathOfPosting = this.pathOfPosting + "/WithStem/";
            if (!theDir.exists()) {
                theDir.mkdir();
            }
        }
        else {
            theDir = new File(this.pathOfPosting + "/WithOutStem/");
            this.pathOfPosting = this.pathOfPosting + "/WithOutStem/";
            if (!theDir.exists()) {
                theDir.mkdir();
            }
        }
    }


    /**
     * The function finishes building the inverted indexer
     * @throws IOException
     */
    public void finish() throws IOException {
        executor = null;
        stopWords.clear();
        stopWords = null;
        int numOfUniqueTerms = indexer.finishInvertedIndexer();
        endTime = System.nanoTime();
        long totalTime = endTime - startTime;
        File file = new File (pathOfPosting+"/documents/documents.txt");
        BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
        String line = null;
        int counter=0;
        while ((line = bufferedReader.readLine()) != null) {
            counter++;
        }
        System.out.println("Amount of documents that were indexed: " + counter);
        System.out.println("Amount of unique terms that were identified: " + numOfUniqueTerms);
        System.out.println("Total running time: " + totalTime + " seconds");

        bufferedReader.close();

    }


    /**
     * The function begins building the inverted indexer
     */
    public void start() {
        startTime = System.nanoTime();
        //The threads work on parsing the corpus together
        for (int i = 0; i < 3; i++) {
            executor.execute(() -> {
                try {
                    startReading();
                } catch (IOException | InterruptedException e) {
                    e.printStackTrace();
                }
            });
        }

        try {
            if (!executor.awaitTermination(25, TimeUnit.MINUTES)) {
                executor.shutdownNow();
            }
            finish();

        } catch (InterruptedException | IOException e) {
            e.printStackTrace();
        }
    }


    /**
     * The function begins the process of building the invereted indexer, each thread enters the function, creates a parser
     * And fills the shared dictionary with the parser's data
     * @throws IOException
     * @throws InterruptedException
     */
    private void startReading() throws IOException, InterruptedException {
        Parse parser = new Parse(stopWords, currentThread().getId(), pathOfPosting);
        while (true) {
            int tempNum;
            lock1.lock();
            try {
                tempNum = toGo;
                if (toGo >= numOfFolder-1) {
                    lock1.unlock();
                    break;
                }
                else {
                    toGo=toGo+3;
                    lock1.unlock();
                }
            } finally {

            }
            ReadFile reader = new ReadFile(pathOfCorpus);
            LinkedList<String> documents = reader.readFiles(tempNum);
            for (int i = 0; i < documents.size(); i++) {
                HashMap<String, LinkedList<Term>> bagOfWords = parser.parseArticles(documents.get(i));
                lock2.lock();
                try {
                    indexer.buildInvertedIndexer(bagOfWords);
                    lock2.unlock();
                } finally {

                }
            }
        }
        parser.finishWriteDocuments();
        executor.shutdown(); //shutdown executor
    }
}

