package Model;

import java.io.*;
import java.util.*;

/**
 * The class that represents the reader of the files from a directory
 */
public class ReadFile {

    private String filePath;
    private LinkedList <String> docs;

    /**
     * constructor
     * @param filePath the directory
     */
    ReadFile(String filePath){
        this.filePath=filePath;
        docs = new LinkedList<>();
    }

    /**
     * this is a default constructor
     */
    public LinkedList<String> readFiles(int start) throws IOException {
        File mainDir = new File(filePath);
        String[] subDirs = mainDir.list();
        docs.clear();
        int counter = 0;
        while (start+counter < start+3) {
            if (subDirs.length - 1 > counter + start) {
                File fileDir = new File(filePath + "/" + subDirs[start + counter] + "/" + subDirs[start + counter]);
                try {
                    FileInputStream fileInputStream = new FileInputStream(fileDir);
                    byte[] tempDocByte = new byte[(int) fileDir.length()];
                    fileInputStream.read(tempDocByte);
                    fileInputStream.close();
                    String tempDocString = new String(tempDocByte, "UTF-8");
                    String[] tokens = tempDocString.split("</DOC>");
                    this.docs.addAll(Arrays.asList(tokens));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            counter++;
        }
        return docs;
    }

    /**
     * The function returns a hashset that holds the stop-words in the corpus
     * @return
     * @throws FileNotFoundException
     */
    public HashSet<String> readStopWord () throws FileNotFoundException {
        HashSet<String> stopWords = new HashSet<>();
        File fileDir = new File (filePath+"/"+"stopwords.txt");
        Scanner sc = new Scanner (fileDir);
        String line="";
        while (sc.hasNextLine()){
            line=sc.nextLine();
            stopWords.add(line);
        }
        return stopWords;
    }


}