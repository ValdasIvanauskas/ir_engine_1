package View;

import Model.Handler;
import Model.Indexer;
import Model.PostingFilesMerger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;

import javafx.scene.Scene;
import javafx.scene.control.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import javafx.event.ActionEvent;

public class Controller {

    @FXML
    public TextField toTakeFrom; // corpus directory
    @FXML
    private CheckBox stemmingCheck;
    @FXML
    private TextField toCreateTo; //posting files directory
    @FXML
    private Button takingBrowser;
    @FXML
    private Button createBrowser;
    @FXML
    private Button loadDictionary;
    @FXML
    private Button reset;
    @FXML
    private Button displayDictionary;
    @FXML
    private Button startRunning;
    @FXML
    private Label status;
    @FXML
    public ListView<String> viewLinkedList;

    private PostingFilesMerger postingFilesMerger;
    private Handler handler;
    private String pathOfCorpus;
    private String pathOfPosting;
    private LinkedList<String> listViewLinkedString;




    @FXML
    private void chooseCorpusDir(ActionEvent event) throws IOException {
        Stage stage = new Stage();
        DirectoryChooser chooseDir = new DirectoryChooser();
        File chosenDir = chooseDir.showDialog(stage);
        if (chosenDir != null) {
            toTakeFrom.setText(chosenDir.getAbsolutePath());
            this.pathOfCorpus = chosenDir.getAbsolutePath();
        } else {
            toTakeFrom.setText("No directory was chosen");
        }
    }

    @FXML
    private void choosePostingDir(ActionEvent event) throws IOException {
        Stage stage = new Stage();
        DirectoryChooser chooseDir = new DirectoryChooser();
        File chosenDir = chooseDir.showDialog(stage);
        if (chosenDir == null) {
            toCreateTo.setText("No directory was chosen");
        } else {
            toCreateTo.setText(chosenDir.getAbsolutePath());
            this.pathOfPosting = chosenDir.getAbsolutePath();
        }
    }


    @FXML
    private void resetProgram (ActionEvent event){
        postingFilesMerger = new PostingFilesMerger(pathOfPosting,pathOfCorpus);
        postingFilesMerger.resetAllPostingFiles();
        status.setText("Program is cleared");
    }

    @FXML
    private void Generate() throws FileNotFoundException {
        this.handler = new Handler(pathOfCorpus,pathOfPosting,stemmingCheck.isSelected());
        this.postingFilesMerger = new PostingFilesMerger(pathOfPosting,pathOfCorpus);
        handler.start();
        status.setText("Engine was generated");
    }


    @FXML

    public void showDictionary() throws IOException {

        Indexer tempIndexer = handler.getIndexer();
        listViewLinkedString = new LinkedList<>();
        listViewLinkedString = tempIndexer.showDictionary();
        ObservableList<String> list = FXCollections.observableList(listViewLinkedString);
        viewLinkedList = new ListView<>();
        viewLinkedList.setItems(list);
        Stage stage = new Stage();
        Scene scene = new Scene (viewLinkedList);
        stage.setScene(scene);
        stage.show();
        status.setText("Dictionary is being displayed");
    }





    @FXML
    private void loadDictionary() throws IOException {
        Indexer tempIndexer = handler.getIndexer();
        tempIndexer.writeDictionaryToDisk();
        status.setText("Dictionary is in the disk");
    }

}
