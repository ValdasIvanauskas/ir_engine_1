package sample;

import Model.Indexer;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import org.apache.commons.lang3.StringUtils;

import java.io.*;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class Controller {
    public Button clear_button;
    public Button display_button;
    public Button load_button;
    public CheckBox stemming_checkBox;
    public TextField corpusPath_textField;
    public Label corpus_label;
    public Button browse_corpus_button;
    public Button browse_postFile_button;
    public TextField posting_textFeild;
    public Label posting_label;
    public Label Header_label;
    public Button buildInvertedIndex_button;

    public Stage mainStage;
    public Scene mainScene;

    public String corpusPath="";
    public String postingPath="";

    public Indexer indexer;

    public void initialize( Stage mainStage, Scene mainScene) {
        this.mainScene = mainScene;
        this.mainStage = mainStage;
    }

    /**
     * opens the browser to select the corpus path
     */
    public void browseCorpus(){
        DirectoryChooser fc = new DirectoryChooser();
        fc.setTitle("Corpus Path");
        File filePath = new File("./SearchEngine/");//????????????????
        if (!filePath.exists())
            filePath.mkdir();
        fc.setInitialDirectory(filePath);

        File selectedDirectory = fc.showDialog(mainStage);

        //Make sure a file was selected, if not return default

        if(selectedDirectory == null){
            //No Directory selected
        }else{
            corpusPath=selectedDirectory.getAbsolutePath();
            corpusPath_textField.setText(corpusPath);
        }
    }
    /**
     * opens the browser to select the corpus path
     */
    public void browsePosting(){
        DirectoryChooser fc = new DirectoryChooser();
        fc.setTitle("Posting Path");
        File filePath = new File("./SearchEngine/");//????????????????
        if (!filePath.exists())
            filePath.mkdir();
        fc.setInitialDirectory(filePath);

        File selectedDirectory = fc.showDialog(mainStage);

        //Make sure a file was selected, if not return default

        if(selectedDirectory == null){
            //No Directory selected
        }else{
            postingPath=selectedDirectory.getAbsolutePath();
            posting_textFeild.setText(postingPath);
        }
    }

    /**
     * build the whole inverted index and dictionary
     */
    public void buildInvertedIndex(){
        if(corpusPath.length()==0 || postingPath.length()==0){
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Impotant Message!!!!");
            //alert.getDialogPane().getStylesheets().add("Popup.css");
            alert.setHeaderText("You didn't choose corpus and posting paths. Please choose and try again :)");
            //alert.setContentText("blalalalalaa");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK){
                alert.close();
            } else {
                alert.close();
            }
        }
        else{
            if(stemming_checkBox.isSelected()){// with stemming
                indexer=new Indexer(corpusPath,postingPath,true);
            }
            else{//without stemming
                indexer=new Indexer(corpusPath,postingPath,false);
            }
            long runtime=indexer.runDictionaryBuilder();
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            if(stemming_checkBox.isSelected()){
                alert.setTitle("Dictionary Details with Stemming!");
            }
            else{
                alert.setTitle("Dictionary Details without Stemming!");
            }
            //alert.getDialogPane().getStylesheets().add("Popup.css");
            alert.setHeaderText("Num of Indexed Documents: "+indexer.getNumOfDocs()+"\n"+
                    "Num of unique terms in corpus: "+ indexer.getDictionary().size()+"\n"+
                    "Total runtime: "+runtime);
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK){
                alert.close();
            } else {
                alert.close();
            }
        }
   }

    /**
     * delete all posting files in path
     */
   public void deletePostingFiles(){
        System.gc();
        File stemFolder= new File(postingPath+"\\withStemmer");
        if(stemFolder.exists()){
            deleteAll(stemFolder);
            stemFolder.delete();
        }
       System.gc();
       File noStemFolder= new File(postingPath+"\\noStemmer");
        if(noStemFolder.exists()){
            deleteAll(noStemFolder);
            noStemFolder.delete();
        }

        if(indexer!=null){
            indexer.indexerClearAll();
        }
   }

    /**
     * delete all file in folder
     * @param folder
     */
   private void deleteAll(File folder){
       System.gc();
       File[] allFiles = folder.listFiles();
       int numOfFiles = allFiles.length;
        File curr;
       for(int i = 0; i < numOfFiles; ++i) {
           curr=allFiles[i];
           if (curr.isFile() && curr.getName().endsWith(".txt")) {
               curr.delete();
           } else {
               deleteAll(curr);
               curr.delete();
           }
       }
   }

    /**
     * represent the dictionary to user
     * @param actionEvent
     */
    public void showDic(ActionEvent actionEvent) {
            TableView <HashMap.Entry<String, String>> table = new TableView();
            Stage stage = new Stage();
            Scene scene = new Scene(new Group());
            stage.setTitle("Table View Sample");
            stage.setWidth(300);
            stage.setHeight(500);

            table.getItems().addAll(indexer.getDictionary().entrySet());


        TableColumn<HashMap.Entry<String, String>, String> column1 = new TableColumn<>("Term");
        column1.setCellValueFactory(param -> new ReadOnlyObjectWrapper<>(param.getValue().getKey()));
        Comparator<String> tComparator = new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return o1.compareTo(o2);
            }
        };
        column1.setComparator(tComparator);

        TableColumn<HashMap.Entry<String, String>, String> column2 = new TableColumn<>("Num in Corpus");
        column2.setCellValueFactory(param -> new ReadOnlyObjectWrapper<>(param.getValue().getValue()));

            table.getColumns().addAll(column1,column2);
            table.getSortOrder().add(column1);
            final VBox vbox = new VBox();
            vbox.setSpacing(5);
            vbox.setPadding(new Insets(10, 0, 0, 10));
            vbox.getChildren().addAll(table);

            ((Group) scene.getRoot()).getChildren().addAll(vbox);

            stage.setScene(scene);
            stage.show();

    }

    /**
     * upload dictionary to memory
     * @param event
     */
    public void uploadDictionary(ActionEvent event){
        String folderPath="";
        if(stemming_checkBox.isSelected()){
            folderPath=postingPath+"\\withStemmer";
        }
        else{
            folderPath=postingPath+"\\noStemmer";
        }
        File folder= new File(folderPath);
        File[] allFiles= folder.listFiles();
        File mergedDoc=null;
        for(int i=0; i< allFiles.length;i++){
            if(allFiles[i].getName().startsWith("merge")){
                mergedDoc=allFiles[i];
            }
        }
        if(indexer==null){
            indexer=new Indexer();
        }
        indexer.clearDictionary();
        try {
            BufferedReader bufferedReader= new BufferedReader(new FileReader(mergedDoc));
            String line = bufferedReader.readLine();
            String[] splited;
            String term;
            String numInCorpus;
            while(line != null){
                splited= StringUtils.split(line,"#");
                term= splited[0];
                numInCorpus=splited[2];
                indexer.addToDictionary(term,numInCorpus);
                line = bufferedReader.readLine();
            }
            bufferedReader.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Dictionary Uploaded");
        //alert.getDialogPane().getStylesheets().add("Popup.css");
        alert.setHeaderText("The dictionary was loaded to memory\n"+
                "Dictionary Size: "+ indexer.getDictionary().size());
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            alert.close();
        } else {
            alert.close();
        }

    }


}
