READ ME
wellcome to the greatest Search Engine of all times!!

HOW TO OPEN RUN FILE
-------------------------------------------------------------
please press on SearchEngineGUIBatch.batch file and the program will start runnting


HOW TO USE THE GUI
--------------------------------------------------------------
The Buttons:

browse corpus path- press browse to select your corpus path. Be sure it is not empty!
	In the corpus path there must be the stop words file.

browse posting path- press browse to select the location where you want the posting files to be saved while the search engine is indexed.

Build Inverted Index- this button creates the inverted index in the posting file path you inserted.

With Stemming Check Box- by checking this box you dicide to build the dictionary with stemming.
	If you wish to build the dictionary without stemming don't check the box.
	
Clear- Be Carefull!!!! This button deletes the posting files and dictionary from your computer.

Display Dictionary- by pressing this button a pop-up screen will apear with the corpus dictionary,sorted by lexicografic order.
	Each word will apear with the number of apearences in the corpus.
	
Load Dictionary from Memory- This button will load the dictionary by the posting files that are in the posting file path entered.

Exit- if you wish to exit the search engine please press the X on the upper left side of the window.
