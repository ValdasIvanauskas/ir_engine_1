package InfoPackage;

import TermsPackage.Term;

import java.util.ArrayList;
import java.util.List;

/**
 * Class for holding information about term
 */
public class TermInfo {

    private int frequencyInCorpus;
    private int numOfDocsIn;
    private String location;


    /**
     * Default constructor for the TermInfo class
     */
    public TermInfo()
    {
        this.frequencyInCorpus = 0;
        numOfDocsIn = 0;
        location = "";
    }


    /**
     * Constructor for the TermInfo Class
     * @param frequencyInCorpus the frequency of the term in all of the corpus
     * @param location The location of the term in the posting file
     */
    public TermInfo(int frequencyInCorpus, String location) {
        this.frequencyInCorpus = frequencyInCorpus;
        this.location = location;
    }


    /**
     * Add occurence of the term in some document in the corpus
     * @param numOfTimesInDoc The number of times the term appeared in the document
     */
    public void addOccurenceOfTerm(int numOfTimesInDoc)
    {
        this.frequencyInCorpus += numOfTimesInDoc;
        this.numOfDocsIn++;
    }


    /**
     * Setter for the location of the term in the posting files
     * @param location
     */
    public void setLocation(String location)
    {
        this.location = location;
    }


    /**
     * Getter for the location of the term in the posting file
     * @return
     */
    public String getLocation() {
        return location;
    }


    /**
     * Getter for the frequency of the term in all of the corpus
     * @return
     */
    public int getFrequencyInCorpus()
    {
        return frequencyInCorpus;
    }


    /**
     * Getter for the number of documents the term appeared in
     * @return The number of documents the term appeared in
     */
    public int getDocFrequency()
    {
        return numOfDocsIn;
    }


    /**
     * Combine the data of 2 TermInfo classes
     * @param termInfo The TermInfo to combine with
     */
    public void addNewTermInfo(TermInfo termInfo)
    {
        this.frequencyInCorpus += termInfo.frequencyInCorpus;
        this.numOfDocsIn += termInfo.numOfDocsIn;
    }
}
