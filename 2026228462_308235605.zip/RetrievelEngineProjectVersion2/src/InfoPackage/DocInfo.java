package InfoPackage;

/**
 * Class for containing information about document
 */
public class DocInfo {

    private int numOfTermsInDoc;
    private int maxTF;
    private int docVectorLength;


    /**
     * Constructor for DocInfo class
     */
    public DocInfo()
    {
        this.numOfTermsInDoc = 0;
        this.maxTF = 0;
        this.docVectorLength = 0;
    }


    /**
     * Add appearance of certain term number of times in the document
     * @param numOfSpecificTermInDoc The number of time the term appeared in the document
     */
    public void addTermsToDoc(int numOfSpecificTermInDoc) {
        this.numOfTermsInDoc += numOfSpecificTermInDoc;
        this.maxTF = Math.max(maxTF, numOfSpecificTermInDoc);
        this.docVectorLength += Math.pow(numOfSpecificTermInDoc,2);
    }


    /**
     * getter for the number of terms in the document
     * @return The number of unique words in the document
     */
    public int getNumOfTermsInDoc() {
        return numOfTermsInDoc;
    }


    /**
     * Getter for the number of time the most common word appeared in the document
     * @return
     */
    public int getMaxTF() {
        return maxTF;
    }


    /**
     * Getter for the result of the next formula: Sum[(frequency of each word in the document)^2]
     * @return
     */
    public double getDocVectorLength() {
        return docVectorLength;
    }
}
