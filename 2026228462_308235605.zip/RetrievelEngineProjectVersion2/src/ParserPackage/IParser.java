package ParserPackage;

/**
 * Interface for parser
 */
public interface IParser {

    void parseDocs();

}
