package TermsPackage;

import Document.Document;

/**
 * Class representing phone number
 */
public class PhoneTerm extends Term {

    private String phone;


    /**
     * Constructor for the PhoneTerm class
     * @param term String representing the phone number
     * @param doc Document holding the term
     */
    public PhoneTerm(String term, Document doc)
    {
        super(doc);
        this.phone = term.replaceAll("\\s", " ");
    }


    @Override
    public String toString() {
        return this.phone;
    }
}
