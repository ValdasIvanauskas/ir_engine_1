package ReadFilePackage;

import Document.Document;

import java.util.List;

public interface IReadFile {

    List<Document> getDocs(int numOfDocs);
}
