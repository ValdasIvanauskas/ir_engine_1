package GUIPackage;

import ComperatorPackage.MapEntryComparator;
import IndexerPackage.MapReduceIndexer;
import InfoPackage.DocInfo;
import InfoPackage.TermInfo;
import ParserPackage.RegexParser;
import ReadFilePackage.ReadFile;
import TermsPackage.WordTerm;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;

import java.awt.Button;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


@SuppressWarnings("ALL")
public class Controller {

    //View Variable
    private Scene mainScene;
    private Stage mainStage;

    //The Corresponding variables
    private String pathToCorpus;
    private String pathToIndexer;
    private String pathToIndexerWithWithoutStem;
    private Boolean isStem;
    private Boolean pathCorpusChoose = false;
    private Boolean pathIndexChoose = false;

    //The GUI Variable
    @FXML
    private TextField textField_toCorpus;
    @FXML
    private TextField textField_toIndex;
    @FXML
    private CheckBox checkBox_Steam;
    @FXML
    private Button buttonXmlOeffnen;

    Hashtable<String, TermInfo> termDict;
    Hashtable<String, DocInfo> docDict;


    /**
     * Constructor for the Controller
     */
    public Controller() {

        isStem = false;
        RegexParser.setStem(false);
        pathToIndexerWithWithoutStem = pathToIndexer + "\\Output\\Stem Off";
    }


    /**
     * Uploads The dictionary given by the GUI to termDict variable
     */
    public void uploadDicToRam() {

        if(!pathIndexChoose || Files.notExists(Paths.get(pathToIndexer + "\\Output"))){
            showAlert("Invalid Path inserted");
            return;
        }


        try {
            File indexDirectory = new File(pathToIndexerWithWithoutStem);

            int indexCount = indexDirectory.list().length - 1;

            File dictionary = new File(pathToIndexerWithWithoutStem + "\\Index" + indexCount + "\\Term Dictionary\\dictionary");
            BufferedReader reader = new BufferedReader(new FileReader(dictionary));
            String line;
            this.termDict = new Hashtable<>();
            while((line = reader.readLine()) != null)
            {
                String[] lineSplitted = line.split("[:|]");
                termDict.put(lineSplitted[0], new TermInfo(Integer.parseInt(lineSplitted[1]), lineSplitted[2]));
            }

        } catch(IOException e)
        {
            showAlert("Invalid Path inserted");
            return;
        }


        showAlert("Dictionary Uploaded");

    }


    /**
     * Delete all the output folders and files of the Search Engine
     */
    public void deleteIndex() {

        if(Files.notExists(Paths.get(pathToIndexer + "\\Output")))
        {
            showAlert("Invalid path");
            return;
        }

        deleteFolderOrFile(pathToIndexer + "\\Output");

        showAlert("Index Deleted");

    }


    /**
     * Recursivley deletes the folder Output and all the files and directories inside it
     * @param path
     */
    private void deleteFolderOrFile(String path)
    {
        File file = new File(path);
        String[] entries = file.list();
        for(String s: entries){
            File currentFile = new File(file.getPath(), s);
            if(currentFile.isDirectory())
                deleteFolderOrFile(currentFile.getPath());

            currentFile.delete();
        }
        file.delete();
    }


    /**
     * Opens windows file explorer to choose the wanted path for the corpus and updates pathToCorpus variable with it
     */
    public void chooseDirToCorpus() {
        DirectoryChooser directoryChooser = new DirectoryChooser();
        File selectedDirectory = directoryChooser.showDialog(mainStage);

        if (selectedDirectory == null) {
            //No Directory selected
        } else {
            this.pathToCorpus = selectedDirectory.getAbsolutePath();
            this.pathCorpusChoose = true;
            textField_toCorpus.setText(this.pathToCorpus);
        }
    }


    /**
     * Opens windows file explorer to choose the wanted path for the Posting files and dictionaries and updates pathToIndexer variable with it
     */
    public void chooseDirToIndex() {
        DirectoryChooser directoryChooser = new DirectoryChooser();
        File selectedDirectory = directoryChooser.showDialog(mainStage);

        if (selectedDirectory == null) {
            //No Directory selected
        } else {
            this.pathToIndexer = selectedDirectory.getAbsolutePath();
            this.pathIndexChoose = true;
            textField_toIndex.setText(this.pathToIndexer);
            this.setStem();
        }
    }


    /**
     * Pop message with the given text on the screen
     * @param alertMessage The message to show
     */
    private void showAlert(String alertMessage) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText(alertMessage);
        alert.show();
    }


    /**
     * Shows The dictionary that is currently on the Ram
     */
    public void presentDictionary() {
        try {
            if(termDict != null)
            {
                Stage stage = new Stage();
                stage.setTitle("Dictionary");

                ObservableList<TermData> termData = FXCollections.observableArrayList();
                for(Map.Entry<String,TermInfo> entry : termDict.entrySet())
                {
                    termData.add(new TermData(entry.getKey(), entry.getValue().getFrequencyInCorpus()));
                }

                TableColumn firstNameCol = new TableColumn();
                firstNameCol.setText("term");
                firstNameCol.setCellValueFactory(new PropertyValueFactory("term"));
                firstNameCol.setComparator(String.CASE_INSENSITIVE_ORDER);

                TableColumn lastNameCol = new TableColumn();
                lastNameCol.setText("Frequency");
                lastNameCol.setCellValueFactory(new PropertyValueFactory("numOfAppearences"));

                TableView tableView = new TableView();
                tableView.setItems(termData);
                tableView.getColumns().addAll(firstNameCol, lastNameCol);
                tableView.getSortOrder().add(firstNameCol);

                Scene scene = new Scene(tableView);
                stage.setScene(scene);
                stage.show();

            }

        } catch (Exception e) {

        }
    }


    /**
     * Main function. Parsing all of the documents in the Corpus and Indexing the terms inside it to dictionary and Posting Files.
     * Saves all kind of detailes  on the documents
     */
    public void indexCorpus() {

        if(!pathCorpusChoose || ! pathIndexChoose){
            showAlert("Invalid Path inserted");
            return;
        }

        //<editor-fold desc="Init directories">
        File directory = new File(pathToIndexer + "\\Output");
        if (!directory.exists())
            directory.mkdirs();

        File indexDirectory = new File(pathToIndexerWithWithoutStem);

        if(!indexDirectory.exists())
            indexDirectory.mkdirs();

        int indexCount = indexDirectory.list().length;


        try {
            Files.createDirectory(Paths.get(pathToIndexerWithWithoutStem + "\\Index" + indexCount));
            Files.createDirectory(Paths.get(pathToIndexerWithWithoutStem + "\\Index" + indexCount + "\\Temp"));
            Files.createDirectory(Paths.get(pathToIndexerWithWithoutStem + "\\Index" + indexCount + "\\Posting Files"));
            Files.createDirectory(Paths.get(pathToIndexerWithWithoutStem + "\\Index" + indexCount +"\\Term Dictionary"));
            Files.createDirectory(Paths.get(pathToIndexerWithWithoutStem + "\\Index" + indexCount +"\\Document Dictionary"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        //</editor-fold>

        //<editor-fold desc="Init vars to index">
        termDict = new Hashtable<>();
        docDict = new Hashtable<>();

        ExecutorService pool = Executors.newFixedThreadPool(5);
        ExecutorService pool2 = Executors.newFixedThreadPool(5);

        ReadFile fileReader = new ReadFile(pathToCorpus);

        WordTerm.setStopWords(pathToCorpus);

        double startTime = System.currentTimeMillis();

        RegexParser.initLocks();
        //</editor-fold>

        //<editor-fold desc="Parsing">
        for (int i = 0 ; i<5 ; i++) {
            RegexParser parser1 = new RegexParser(fileReader, 5000, pathToIndexerWithWithoutStem + "\\Index" + indexCount, 20);
            pool.execute(parser1);
        }

        pool.shutdown();

        while(!pool.isTerminated()){}
        //</editor-fold>

        //<editor-fold desc="Indexing">
        for (int i = 0 ; i<5 ; i++) {
            MapReduceIndexer mapReduceIndexer1 = new MapReduceIndexer(pathToIndexerWithWithoutStem + "\\Index" + indexCount, termDict, docDict, (20/5)*i, (20/5)+((20/5)*i), 200);
            pool2.execute(mapReduceIndexer1);
        }

        pool2.shutdown();

        while(!pool2.isTerminated()) {}
        //</editor-fold>

        //<editor-fold desc="Writing dictionaries">
        ArrayList<Map.Entry<String, TermInfo>> termDictList = new ArrayList<>(termDict.entrySet());
        Collections.sort(termDictList, new MapEntryComparator());

        StringBuilder termDictionary = new StringBuilder();
        StringBuilder docDictionary = new StringBuilder();

        // Preparing term dictionary to writing proccess
        for(Map.Entry<String, TermInfo> entry : termDictList)
        {
            termDictionary.append(entry.getKey() + ":" + entry.getValue().getFrequencyInCorpus() + "|" + entry.getValue().getLocation() + "\n");
        }

        // Preparing document dictionary to writing proccess
        for(Map.Entry<String, DocInfo> entry : docDict.entrySet())
        {
            docDictionary.append(entry.getKey() + ":" + entry.getValue().getNumOfTermsInDoc() + "," + entry.getValue().getMaxTF() + "," + entry.getValue().getDocVectorLength() + "\n");
        }

        // Writing all dictionaries and deleting temp directory
        try {
            Files.delete(Paths.get(pathToIndexerWithWithoutStem + "\\Index" + indexCount + "\\Temp"));
            Files.write(Paths.get(pathToIndexerWithWithoutStem + "\\Index" + indexCount + "\\Term Dictionary\\Dictionary"),termDictionary.toString().getBytes());
            Files.write(Paths.get(pathToIndexerWithWithoutStem + "\\Index" + indexCount + "\\Document Dictionary\\Dictionary"),docDictionary.toString().getBytes());
        } catch (IOException e) { e.printStackTrace(); }
        //</editor-fold>

        double endTime = System.currentTimeMillis();

        showAlert("Number Of Indexed Documents: " + fileReader.getNumOfIndexedDocs() +
                                "\nNumber Of Unique Terms In Corpus: " + termDict.size() +
                                "\nIndex Total Time: " + ((endTime-startTime)/1000) + " Seconds");



    }


    /**
     * Turning the stem option on or off by the check box in the GUI
     */
    public void setStem()
    {
        this.isStem = checkBox_Steam.isSelected();
        if(isStem)
            pathToIndexerWithWithoutStem = pathToIndexer + "\\Output\\Stem On";
        else
            pathToIndexerWithWithoutStem = pathToIndexer + "\\Output\\Stem Off";
        RegexParser.setStem(isStem);
    }

    /**
     * Inner Class for the presentDictionary
     */
    public class TermData {
        String term;
        int numOfAppearences;

        public TermData(String term, int numOfAppearences) {
            this.term = term;
            this.numOfAppearences = numOfAppearences;
        }

        public String getTerm() {
            return term;
        }

        public int getNumOfAppearences() {
            return numOfAppearences;
        }

        public void setTerm(String term) {
            this.term = term;
        }

        public void setNumOfAppearences(int numOfAppearences) {
            this.numOfAppearences = numOfAppearences;
        }
    }
}



