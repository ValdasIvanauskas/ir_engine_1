Search Engine Application:

This application allows you to Index corpus of documents into Inverse Index.

How To use the amazing Search Engine:

Creating New Index:
1.Choose and load the corpus folder to be Indexed.
2.Choose where you want the Posting file and Dictionary.
3.Click the “Steam it” choose box for stemmed Index, default is without steaming.
4.Click on “Create Index”.
5.The Inverted Index will appear in the given path, inside folder named Output.

Deleting the current Posting file and Dictionary:
#Warning: The delete button deletes the output file in the given path to index, if there is a folder named Output it will be deleted.
1. Choose where the Posting file and Dictionary to be deleted is located.
2.Click the “Delete” button.

Upload Dictionary to the memory:
1. Choose where the Posting file and Dictionary to be uploaded is located.
2.Click on “Upload Dictionary”.

Show the dictionary loaded to the memory:
If index Just created:
1.Click “Show Dictionary”.

Index was created before:
1.Choose the path to the inverted index. 
2.Click on “Upload Dictionary”.
3.Click “Show Dictionary.


Created by: S.Freiman and O.Epshtein

Enjoy ;)