import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    /**
     * Main class, entry point for the program
     * @param args
     */
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Information Retrieval");
        Class myclass=getClass();
        myclass.getResource("MyView.fxml");
        Parent root = FXMLLoader.load(getClass().getResource("gui/MyView.fxml"));
        Scene scene = new Scene(root,810,300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
