package gui;

import impl.FrameWork.IRManager;
import impl.Structures.TermInfo;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.ImagePattern;
import javafx.stage.Stage;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class MyViewController extends Component implements Initializable {
    //<editor-fold desc="Local variables">
    static Map<String, TermInfo> myDictionary;
    public javafx.scene.control.Button bt_show_dictionary;
    public javafx.scene.control.Button bt_load_dictionary;
    public javafx.scene.control.TextField txt_corpus_path;
    public javafx.scene.control.TextField txt_posting_path;
    public javafx.scene.image.ImageView usImage;
    public javafx.scene.layout.HBox hBox;
    public javafx.scene.control.CheckBox cb_stemming;
    public IRManager myManger;
    public String postingFilePath;
    public String corpusPath;
    //</editor-fold>

    //<editor-fold desc="Helping Methods">

    /**
     * Setting our image in the menu
     *
     * @param location
     * @param resources
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        Image ourImage = null;
        try {
            ourImage = new Image(getClass().getResourceAsStream("/Itai_Alisa.jpeg"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        BackgroundFill bgi = new BackgroundFill(new ImagePattern(ourImage), CornerRadii.EMPTY, Insets.EMPTY);
        hBox.setBackground(new Background(bgi));
    }

    /**
     * corpus files directory
     */
    public void browseDictionary() {
        JFileChooser chooser = new JFileChooser();
        chooser.setCurrentDirectory(new java.io.File("."));
        chooser.setDialogTitle("Choose your corpus");
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        chooser.setAcceptAllFileFilterUsed(false);
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            corpusPath = String.valueOf(chooser.getSelectedFile());
            txt_corpus_path.setText(String.valueOf(chooser.getSelectedFile()));
        }

    }

    /**
     * posting files directory
     */
    public void browsePostingFile() {
        JFileChooser chooser = new JFileChooser();
        chooser.setCurrentDirectory(new java.io.File("./postingFile/"));
        chooser.setDialogTitle("Choose directory where to save the posting file");
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        chooser.setAcceptAllFileFilterUsed(false);
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            postingFilePath = String.valueOf(chooser.getSelectedFile());
            txt_posting_path.setText(String.valueOf(chooser.getSelectedFile()));
        }
    }

    /**
     * Change the photo once clicking on the stemming box
     *
     * @param actionEvent
     */
    public void changePhoto(ActionEvent actionEvent) {
        Image ourImage = null;
        if (cb_stemming.isSelected()) {
            try {
                ourImage = new Image(getClass().getResourceAsStream("/Alisa_Itai.jpeg"));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            try {
                ourImage = new Image(getClass().getResourceAsStream("/Itai_Alisa.jpeg"));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        BackgroundFill bgi = new BackgroundFill(new ImagePattern(ourImage), CornerRadii.EMPTY, Insets.EMPTY);
        hBox.setBackground(new Background(bgi));
    }
    //</editor-fold>

    //<editor-fold desc="Functions">

    /**
     * Start the process of reading parsing and indexing
     *
     * @throws IOException
     */
    public void startIR() throws IOException {
        boolean stemming = cb_stemming.isSelected();
        if (corpusPath != null && postingFilePath != null) {
            if (myManger == null) {
                myManger = new IRManager(corpusPath, postingFilePath);
            }
            myManger.startIR(stemming);
        } else {
            JOptionPane.showMessageDialog(null, "Please enter path in both fields above");
            return;
        }
        Long myMangerTotalTime = myManger.getTotalTime();
        long minutes = TimeUnit.MILLISECONDS.toMinutes(myMangerTotalTime);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(myMangerTotalTime) - TimeUnit.MINUTES.toSeconds(minutes);
        String detailsToShow = "Total time to create the dictionary: " + minutes + "MIN, " + seconds + " SEC" + "\n" + "Number of unique terms: " + myManger.getTermSize() + "\n" + "Number of documents that were indexed: " + myManger.getDocSize();
        JOptionPane.showMessageDialog(null, detailsToShow);
    }

    /**
     * clear the data
     */
    public void reset() {
        if (postingFilePath != null) {
            if (myManger.resetIR(postingFilePath)) {
                txt_corpus_path.setText("");
                txt_posting_path.setText("");
                cb_stemming.setSelected(false);
                if (myDictionary != null)
                    myDictionary.clear();
                myManger = null;
            }
        }
    }

    /**
     * Showing the dictionary
     *
     * @param actionEvent
     */
    public void showDictionary(ActionEvent actionEvent) {
        if (!(myManger == null || myManger.getTermSize() == 0)) {
            Map<String, TermInfo> myDict = myManger.getTermsDictionary();
            List<String> sortedKeys = new ArrayList<>(myDict.keySet());
            Collections.sort(sortedKeys);
            TableView myTable = new TableView();
            TableColumn<String, keyValue> column1 = new TableColumn<>("Term");
            TableColumn<Integer, keyValue> column2 = new TableColumn<>("Total TF");
            column1.setCellValueFactory(new PropertyValueFactory<>("Term"));
            column2.setCellValueFactory(new PropertyValueFactory<>("TTF"));
            myTable.getColumns().add(column1);
            myTable.getColumns().add(column2);
            for (int i = 0; i < sortedKeys.size(); i++) {
                String s = sortedKeys.get(i);
                myTable.getItems().add(new keyValue(s, myDict.get(s).getTotalTermFrequency()));
            }
            myTable.setEditable(true);
            myTable.getSelectionModel().setCellSelectionEnabled(true);
            Stage stage = new Stage();
            stage.setTitle("Our Term Dictionary");
            StackPane sp = new StackPane(myTable);
            Scene scene = new Scene(sp, 600, 800);
            stage.setScene(scene);
            stage.show();
        } else {
            JOptionPane.showMessageDialog(null, "There isn't dictionary to show, please upload one or create one by clicking 'Start')");
        }
    }

    /**
     * loading the dictionary once the user clicked on it
     *
     * @throws IOException
     */
    public void loadDictionary() throws IOException {
        if (myManger == null) {
            myManger = new IRManager(corpusPath, postingFilePath);
        }
        try {
            myManger.loadDictionary(cb_stemming.isSelected(), postingFilePath);
            JOptionPane.showMessageDialog(null, "Congrats! The dictionary is loaded in our system and ready to be checked :)");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Please check if the posting files you try to load are exist and matches the stemming option.");
        }
    }

    //</editor-fold>

    //<editor-fold desc="Private static class">
    public static class keyValue {
        private SimpleIntegerProperty TTF;
        private SimpleStringProperty Term;

        public keyValue(String term, Integer Ttf) {
            this.TTF = new SimpleIntegerProperty(Ttf);
            this.Term = new SimpleStringProperty(term);
        }

        public int getTtf() {
            return TTF.get();
        }

        public SimpleIntegerProperty ttfProperty() {
            return TTF;
        }

        public String getTerm() {
            return Term.get();
        }

        public SimpleStringProperty termProperty() {
            return Term;
        }

        public void setTtf(int ttf) {
            this.TTF.set(ttf);
        }

        public void setTerm(String term) {
            this.Term.set(term);
        }
    }
    //</editor-fold>
}

