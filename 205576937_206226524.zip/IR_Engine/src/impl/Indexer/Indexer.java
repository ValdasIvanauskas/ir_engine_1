package impl.Indexer;
import impl.Parse.CONFIG_CONSTANTS;
import impl.Structures.DocInfo;
import impl.Structures.Document;
import impl.Structures.TermInfo;
import javafx.util.Pair;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.*;

public class Indexer {
    //<editor-fold desc="Local Variables">
    private static final char[] FILENAMES = "ACDFIMPRST#".toCharArray();
    private static final int THRESHOLD = 1;
    private static final HashMap<Character, Character> mapping = createMap();
    private int counter = 0;
    private HashMap<Long, DocInfo> documentsDictionary;
    private HashMap<String, TermInfo> termsDictionary;
    private String stemmed;
    private String postingFilePath;
    private Comparator<String> comparator = (s1, s2) -> {
        int result = s1.compareToIgnoreCase(s2);
        if (result == 0)
            result = s1.compareTo(s2);
        return result;
    };
    //</editor-fold>

    //<editor-fold desc="Constructors">
    public Indexer(boolean stemming, String postingFilePath) {
        documentsDictionary = new HashMap<>();
        termsDictionary = new HashMap<>();
        this.postingFilePath = postingFilePath;
        //Check if stemming needed and save that for the file name
        if (stemming) {
            stemmed = "_S";
        } else {
            stemmed = "_NS";
        }
    }

    /**
     * Static function for mapping each term by is first letter to the relevant post file
     * Each posting file has a name that based on the first letter of a alphabet that stored in it
     * The distribution was made according to statistics so each file will have approximately the same number of terms
     * @return
     */
    private static HashMap<Character, Character> createMap() {
        HashMap<Character, Character> myMap = new HashMap<>();
        myMap.put('A', 'A');
        myMap.put('B', 'A');
        myMap.put('C', 'C');
        myMap.put('D', 'D');
        myMap.put('E', 'D');
        myMap.put('F', 'F');
        myMap.put('G', 'F');
        myMap.put('H', 'F');
        myMap.put('I', 'I');
        myMap.put('J', 'I');
        myMap.put('K', 'I');
        myMap.put('L', 'I');
        myMap.put('M', 'M');
        myMap.put('N', 'M');
        myMap.put('O', 'M');
        myMap.put('P', 'P');
        myMap.put('Q', 'P');
        myMap.put('R', 'R');
        myMap.put('S', 'S');
        myMap.put('T', 'T');
        myMap.put('U', 'T');
        myMap.put('V', 'T');
        myMap.put('W', 'T');
        myMap.put('X', 'T');
        myMap.put('Y', 'T');
        myMap.put('Z', 'T');
        return myMap;
    }
    //</editor-fold>

    //<editor-fold desc="Class functionality methods">

    /**
     * Merge all the terms that have been created to batch od document and merge the same terms into one with all the doc&freq
     * Called by the IRmanger function, readParseAndMergeBatch, after reading and creating posting file for batch
     * @param documentList
     * @throws IOException
     */
    public void mergeAndSortTerms(List<Document> documentList) throws IOException {
        //initialize
        HashMap<Character, HashMap<String, HashMap<Long, Integer>>> sortedTerms = getCharacterTreeMapHashMap();
        boolean isUpper;
        String upperTerm;

        //Foreach document that have been parsed in this batch
        for (Document document : documentList) {
            HashMap<String, Integer> currDocumentTerm = document.getTermsOfDocument();
            long currDocId = document.getDoc_ID();
            for (String term : currDocumentTerm.keySet()) {
                isUpper = Character.isUpperCase(term.charAt(0));
                upperTerm = term.toUpperCase();
                int currFrequency = currDocumentTerm.get(term);
                HashMap<String, HashMap<Long, Integer>> alphaBietTree;
                //???
                if (startWithLetter(term)) {
                    alphaBietTree = sortedTerms.get(mapping.get(Character.toUpperCase(term.charAt(0))));
                } else {
                    alphaBietTree = sortedTerms.get('#');
                }
                //Check if the current word is already exist in the current batch and have been added to the alphaBietTree
                if (isUpper) {
                    term = term.toLowerCase();
                    //If the word is upper check that there isn't the same word in lower case
                    //if there is add to the lower term the doc&frequency according to the parse roles
                    if (alphaBietTree.containsKey(term)) {
                        alphaBietTree.get(term).put(currDocId, currFrequency);
                    } else if (alphaBietTree.containsKey(upperTerm)) {
                        alphaBietTree.get(upperTerm).put(currDocId, currFrequency);
                    } else {
                        HashMap<Long, Integer> termTree = new HashMap<>();
                        termTree.put(currDocId, currFrequency);
                        alphaBietTree.put(upperTerm, termTree);
                    }
                } else {
                    //If the word is lower case, check that there isn't the same word in upper case
                    //If there is add the lower word, copy to this word all the upper word doc&frequency and override the upper word according to the parse roles
                    if (alphaBietTree.containsKey(upperTerm)) {
                        alphaBietTree.put(term, alphaBietTree.get(upperTerm));
                        alphaBietTree.get(term).put(currDocId, currFrequency);
                        if(!upperTerm.equals(term))
                            alphaBietTree.remove(upperTerm);
                    } else if (alphaBietTree.containsKey(term)) {
                        alphaBietTree.get(term).put(currDocId, currFrequency);
                    } else {
                        HashMap<Long, Integer> termTree = new HashMap<>();
                        termTree.put(currDocId, currFrequency);
                        alphaBietTree.put(term, termTree);
                    }
                }
            }
            //Add to documentsDictionary this doc and his info
            documentsDictionary.put(document.getDoc_ID(), document.getDocInfo());
        }
        //Write to the disk all the info sorted by the function (both terms and docID)
        writeAllFiles(sortedTerms);
    }

    /**
     * Merge all the posting files that were created during the process, after that all the files have been handling
     * Called by the IRmanger function, start.
     * @throws IOException
     */
    public void mergeAllFiles() throws IOException {
        for (char filename : FILENAMES) {
            //Set the inner counter to follow who many files lefter to read and merge
            int innerCounter = counter - 1;
            int docNum = 0;
            while (innerCounter > 0) {
                for (int j = 0; j < innerCounter; j += 2, docNum++) {
                    //Read filed content and delete them from the disk
                    List<Pair<String, List<Pair<Long, Integer>>>> file1 = readFromFile(filename + String.valueOf(j));
                    List<Pair<String, List<Pair<Long, Integer>>>> file2 = readFromFile(filename + String.valueOf(j + 1));
                    Path file = Paths.get(postingFilePath + "/" + filename + j + ".txt");
                    Files.delete(file);
                    file = Paths.get(postingFilePath + "/" + filename + (j + 1) + ".txt");
                    Files.delete(file);
                    //Send two files content from merging to one
                    List<Pair<String, List<Pair<Long, Integer>>>> mergedFile = mergeTwoFiles(file1, file2);
                    writeToFile(String.valueOf(filename) + docNum, mergedFile);
                    //???
                    if (j == innerCounter - 2) {
                        docNum++;
                        renameFile(filename + String.valueOf(j + 2), String.valueOf(filename) + docNum);
                    }
                }
                docNum = 0;
                innerCounter = innerCounter / 2;
            }
        }
        //In the end change all the files name to final name ("A_NS" for not stemming and "A_S" for stemming)
        for (char filename : FILENAMES) {
            renameFile(filename + "0", filename + stemmed);
        }
    }

    /**
     *Create a dictionary from all the posting files and merge them to one final posting file
     * Reasonable to remove suspected as entities terms and terms which no exceed the threshold
     * Called by the IRmanger function, start, in teh end
     * @return
     * @throws IOException
     */
    public Map<String, TermInfo> createDictionary() throws IOException {
        boolean firstTime = true;
        //Line counter for a pointer to the relevant line in the posting file
        int lineCounter = 0;
        //Load from the disk each time a  one posting file, delete him and after processing add him t the final posting file
        for (char filename : FILENAMES) {
            List<Pair<String, List<Pair<Long, Integer>>>> file = readFromFile(filename + stemmed);
            Path filePath = Paths.get(postingFilePath + "/" + filename + stemmed + ".txt");
            Files.delete(filePath);
            for (int j = 0; j < file.size(); j++) {
                List<Pair<Long, Integer>> docsList = file.get(j).getValue();
                String term = file.get(j).getKey();
                //The posting file is sorted by UPPERCASE<LOWERCASE for the same char
                //For each term check if is appear in his lower case and if so merge them according to the parse roles
                if (j + 1 < file.size() && term.equals(file.get(j + 1).getKey().toUpperCase())) {
                    file.get(j + 1).getValue().addAll(docsList);
                    file.remove(j);
                    term = file.get(j).getKey();
                    docsList = file.get(j).getValue();
                }
                int size = docsList.size();
                //An entity is a sequence of words that are separated by a space
                boolean is_entity = term.contains(" ") && !Character.isDigit(term.charAt(0));
                //Check the threshold (2) for entity
                if(is_entity && size<2) {
                    Pair<Long, Integer> docAndFreq = docsList.get(0);
                    //Decrease the unique terms for term's document
                    documentsDictionary.get(docAndFreq.getKey()).decreaseUnique_terms();
                    file.remove(j);
                    j--;
                    continue;
                }
                //Sort all the document by the key (docID)
                file.get(j).getValue().sort(Comparator.comparing(Pair::getKey));
                //Calculate for the term hid total frequency by going throw all his document&frequency
                int totalFrequency = 0;
                for (Pair<Long, Integer> stringIntegerPair : docsList) {
                    totalFrequency += stringIntegerPair.getValue();
                }
                termsDictionary.put(term, new TermInfo(size,totalFrequency , lineCounter));
                lineCounter++;
            }
            //If it is the first time that we go throw the files create a new final posting file
            if(firstTime){
                Files.deleteIfExists(Paths.get(postingFilePath + "/postingFile" + stemmed + ".txt"));
                firstTime=false;
            }
            writeToFile("postingFile" + stemmed, file);
        }
        writeDocsDictionaryToFile();
        writeTermsDictionaryToFile();
        return termsDictionary;
    }

    /**
     * Reasonable to write the document dictionary to the disk in the end of the index creating
     * Called by createDictionary
     * @throws IOException
     */
    private void writeDocsDictionaryToFile() throws IOException {
        StringBuilder tobeWritten;
        Path file = Paths.get(postingFilePath + "/documentsDict"+ stemmed + ".txt");
        tobeWritten = new StringBuilder();
        for (Long docID : documentsDictionary.keySet()) {
            tobeWritten.append(docID).append("\t");
            tobeWritten.append(documentsDictionary.get(docID));
            //Limit writing size to avoid exception
            if (tobeWritten.length() > 25000000) {
                //write docID and all his info (docInfo)
                Files.write(file, tobeWritten.toString().getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                tobeWritten = new StringBuilder();
            }
        }
        //Write the last one
        Files.write(file, tobeWritten.toString().getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }

    /**
     * Reasonable to write the term dictionary to the disk in the end of the index creating
     * Called by createDictionary
     * @throws IOException
     */
    private void writeTermsDictionaryToFile() throws IOException {
        StringBuilder tobeWritten;
        Path file = Paths.get(postingFilePath + "/termsDict"+ stemmed + ".txt");
        tobeWritten = new StringBuilder();
        for (String term : termsDictionary.keySet()) {
            tobeWritten.append(term).append("\t");
            tobeWritten.append(termsDictionary.get(term));
            //Limit writing size to avoid exception
            if (tobeWritten.length() > 25000000) {
                //write term and all his info (termInfo)
                Files.write(file, tobeWritten.toString().getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                tobeWritten = new StringBuilder();
            }
        }
        //Write the last one
        Files.write(file, tobeWritten.toString().getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }

    /**
     * Loading all the relevant files that have been created in the createDictionary (termDic, docDic)
     * Called by IRmanger method, loadDictionary
     * @return termsDictionary
     * @throws IOException
     */
    public Map<String, TermInfo> loadDictionary() throws IOException {
        //Find and load the term dictionary
        File file = new File(postingFilePath + "/termsDict" + stemmed + ".txt");
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String strLine;
            while ((strLine = br.readLine()) != null) {
                if (!strLine.isEmpty()) {
                    String[] termsAndInfo = strLine.split("\t");
                    //Extracting variables according to the template in which they were written
                    String term = termsAndInfo[0];
                    int documentFrequency = Integer.parseInt(termsAndInfo[1]);
                    int totalTermFrequency = Integer.parseInt(termsAndInfo[2]);
                    int lineNumberInPosting = Integer.parseInt(termsAndInfo[3]);
                    termsDictionary.put(term, new TermInfo(documentFrequency, totalTermFrequency, lineNumberInPosting));
                }
            }
        }
        //Find and load the document dictionary
        file = new File(postingFilePath + "/documentsDict" + stemmed + ".txt");
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String strLine;
            while ((strLine = br.readLine()) != null) {
                if (!strLine.isEmpty()) {
                    String[] idAndInfo = strLine.split("\t");
                    //Extracting variables according to the template in which they were written
                    long thisID = Long.parseLong(idAndInfo[0]);
                    int max_tf = Integer.parseInt(idAndInfo[1]);
                    int unique_terms = Integer.parseInt(idAndInfo[2]);
                    int doc_length = Integer.parseInt(idAndInfo[3]);
                    String corpus_docno = idAndInfo[4];
                    documentsDictionary.put(thisID, new DocInfo(max_tf, unique_terms, doc_length, corpus_docno));
                }
            }
        }
        return termsDictionary;
    }
    //</editor-fold>

    //<editor-fold desc="Write and Read from File Methods">

    /**
     * Function for write to posting file after they have been sorted in writeAllFiles by using treeMap
     * @param fileName
     * @param termsAndList
     * @throws IOException
     */
    private void writeToFile(String fileName, TreeMap<String, TreeMap<Long, Integer>> termsAndList) throws IOException {
        StringBuilder tobeWritten;
        Path file = Paths.get(postingFilePath + "/" + fileName + ".txt");
        tobeWritten = new StringBuilder();

        //Extracting variables
        for (Object o : termsAndList.keySet()) {
            String term = (String) o;
            tobeWritten.append(term).append("\t\t");
            TreeMap documentsAndOccurrences = termsAndList.get(term);
            for (Object o1 : documentsAndOccurrences.keySet()) {
                long docId = (long) o1;
                int occurrences = (int) documentsAndOccurrences.get(o1);
                tobeWritten.append(docId).append(",").append(occurrences).append("\t");
            }
            tobeWritten.append("\n");
            //Limit writing size to avoid exception
            if (tobeWritten.length() > 10000000) {
                Files.write(file, tobeWritten.toString().getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                tobeWritten = new StringBuilder();
            }
        }
        //Write to the file (append or create)
        Files.write(file, tobeWritten.toString().getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }

    /**
     * Write posting files during the process to the disk, the term are not sorted (using list during the process)
     * Called by  mergeAllFiles and createDictionary
     * @param fileName
     * @param termsAndList
     * @throws IOException
     */
    private void writeToFile(String fileName, List<Pair<String, List<Pair<Long, Integer>>>> termsAndList) throws IOException {
        StringBuilder tobeWritten;
        Path file = Paths.get(postingFilePath + "/" + fileName + ".txt");
        tobeWritten = new StringBuilder();

        //Extracting variables
        for (Pair<String, List<Pair<Long, Integer>>> o : termsAndList) {
            String term = o.getKey();
            tobeWritten.append(term).append("\t\t");
            List<Pair<Long, Integer>> documentsAndOccurrences = o.getValue();
            for (Pair<Long, Integer> o1 : documentsAndOccurrences) {
                long docId = o1.getKey();
                int occurrences = o1.getValue();
                tobeWritten.append(docId).append(",").append(occurrences).append("\t");
            }
            tobeWritten.append("\n");
            //Limit writing size to avoid exception
            if (tobeWritten.length() > 25000000) {
                Files.write(file, tobeWritten.toString().getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                tobeWritten = new StringBuilder();
            }
        }
        //Write to the file (append or create)
        Files.write(file, tobeWritten.toString().getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }

    /**
     * Responsible for reading from file which his name have been given to list (unsorted)
     * Called by createDictionary and mergeAllFiles
     * @param fileName
     * @return
     * @throws IOException
     */
    private List<Pair<String, List<Pair<Long, Integer>>>> readFromFile(String fileName) throws IOException {
        List<Pair<String, List<Pair<Long, Integer>>>> mapping = new ArrayList<>();
        List<String> allLines = new ArrayList<>();
        File file = new File(postingFilePath + "/" + fileName + ".txt");

        //Read all the file line by line to the allLines list
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String strLine;
            while ((strLine = br.readLine()) != null) {
                allLines.add(strLine);
            }
        }
        for (String line : allLines) {
            if (!line.isEmpty()) {
                //Extracting variables
                String[] termAndDoc = line.split("\t\t");
                String thisTerm = termAndDoc[0];
                List<Pair<Long, Integer>> docsWithFrequency = new ArrayList<>();
                String[] docsForTerm = termAndDoc[1].split("\t");
                for (String s : docsForTerm) {
                    String[] docFrequency = s.split(",");
                    docsWithFrequency.add(new Pair<>(Long.valueOf(docFrequency[0]), Integer.valueOf(docFrequency[1])));
                }
                //Add to the list term and his relevent info for the posting file (docID&frequency)
                mapping.add(new Pair<>(thisTerm, docsWithFrequency));
            }
        }
        return mapping;
    }

    //</editor-fold>

    //<editor-fold de sc="Getters">
    public int getDocumentsDictionarySize() {return documentsDictionary.size(); }

    public HashMap<Long, DocInfo> getDocumentsDictionary() { return documentsDictionary; }

    public int getTermsDictionarySize() { return termsDictionary.size(); }

    public HashMap<String, TermInfo> getTermsDictionary() { return termsDictionary; }
    //</editor-fold>

    //<editor-fold desc="Private methods for the class functionality">

    /**
     * Initialize all the hashMap for each posting file, named by the first letter in the first word that stored in the posting file
     * @return a hashMap that contain for each posting file name a her hash of term and relevant info
     */
    private HashMap<Character, HashMap<String, HashMap<Long, Integer>>> getCharacterTreeMapHashMap() {
        //Create
        HashMap<Character, HashMap<String, HashMap<Long, Integer>>> sortedTerms = new HashMap<>();
        HashMap<String, HashMap<Long, Integer>> A = new HashMap<>();
        HashMap<String, HashMap<Long, Integer>> C = new HashMap<>();
        HashMap<String, HashMap<Long, Integer>> D = new HashMap<>();
        HashMap<String, HashMap<Long, Integer>> F = new HashMap<>();
        HashMap<String, HashMap<Long, Integer>> I = new HashMap<>();
        HashMap<String, HashMap<Long, Integer>> M = new HashMap<>();
        HashMap<String, HashMap<Long, Integer>> P = new HashMap<>();
        HashMap<String, HashMap<Long, Integer>> R = new HashMap<>();
        HashMap<String, HashMap<Long, Integer>> S = new HashMap<>();
        HashMap<String, HashMap<Long, Integer>> T = new HashMap<>();
        HashMap<String, HashMap<Long, Integer>> Hash = new HashMap<>();

        //Put foreach letter his hashmap (will store pair of term and hash of doc&frequency
        sortedTerms.put('A', A);
        sortedTerms.put('C', C);
        sortedTerms.put('D', D);
        sortedTerms.put('F', F);
        sortedTerms.put('I', I);
        sortedTerms.put('M', M);
        sortedTerms.put('P', P);
        sortedTerms.put('R', R);
        sortedTerms.put('S', S);
        sortedTerms.put('T', T);
        sortedTerms.put('#', Hash);
        return sortedTerms;
    }

    /**
     * Check if the first char is letter
     * Used for the mergeAndSortTerm to know if to call to one of the alphabet hash or to the numbers hash ("#")
     * @param s
     * @return true if so, otherwise false
     */
    private boolean startWithLetter(String s) {
        return (s.charAt(0) >= 'a' && s.charAt(0) <= 'z') || (s.charAt(0) >= 'A' && s.charAt(0) <= 'Z');
    }

    /**
     * Writing to the posting file (by using writeToFile method) a sorted terms and docs (by using treeMap)
     * File name base on the first char and current counter ("A31")
     * Called by mergeAndSortTerm
     * @param mappingTerms
     * @throws IOException
     */
    private void writeAllFiles(HashMap<Character, HashMap<String, HashMap<Long, Integer>>> mappingTerms) throws IOException {
        //Move to treeMap the list and so we keep terms&docID sorted out as they are written
        for (Character s : mappingTerms.keySet()) {
            TreeMap<String, TreeMap<Long, Integer>> terms = new TreeMap<>(comparator);
            for (String s1 : mappingTerms.get(s).keySet()) {
                TreeMap<Long, Integer> docs = new TreeMap<>();
                docs.putAll(mappingTerms.get(s).get(s1));
                terms.put(s1, docs);
            }
            writeToFile(s.toString() + counter, terms);
        }
        counter++;
    }

    /**
     * merge two files by using Merge Sort algorithm, base on adjusted comparator
     * @param file1
     * @param file2
     * @return one list that conatin all the object form both files sorted
     */
    private List<Pair<String, List<Pair<Long, Integer>>>> mergeTwoFiles
            (List<Pair<String, List<Pair<Long, Integer>>>> file1, List<Pair<String, List<Pair<Long, Integer>>>> file2) {
        //initialize
        int file1Size = file1.size(), file2Size = file2.size();
        int i = 0, j = 0;
        List<Pair<String, List<Pair<Long, Integer>>>> mergedTerms = new ArrayList<>();

        //Merge sort algorithm
        while (i < file1Size && j < file2Size) {
            String file1Term = file1.get(i).getKey();
            String file2Term = file2.get(j).getKey();
            int compareTo = comparator.compare(file1Term, file2Term);
            //Term from file1 is smaller
            if (compareTo < 0) {
                mergedTerms.add(new Pair<>(file1Term, file1.get(i).getValue()));
                i++;
            //Term from file2 is smaller
            } else if (compareTo > 0) {
                mergedTerms.add(new Pair<>(file2Term, file2.get(j).getValue()));
                j++;
            //Both term are equal - take the doc list from both of them and merge into one enter
            } else {
                List<Pair<Long, Integer>> mergeDocsList = new ArrayList<>();
                mergeDocsList.addAll(file2.get(j).getValue());
                mergeDocsList.addAll(file1.get(i).getValue());
                mergedTerms.add(new Pair<>(file2Term, mergeDocsList));
                j++;
                i++;
            }
        }
        //If we didn't red from file all his terms just add them to the end
        while (i < file1Size) {
            String file1Term = file1.get(i).getKey();
            mergedTerms.add(new Pair<>(file1Term, file1.get(i).getValue()));
            i++;
        }
        while (j < file2Size) {
            String file2Term = file2.get(j).getKey();
            mergedTerms.add(new Pair<>(file2Term, file2.get(j).getValue()));
            j++;
        }
        return mergedTerms;
    }

    /**
     * Rename the name1 file to name2
     * @param name1
     * @param name2
     */
    private void renameFile(String name1, String name2) {
        // File (or directory) with old name
        File file = new File(postingFilePath + "/" + name1 + ".txt");
        File file2 = new File(postingFilePath + "/" + name2 + ".txt");
        //If exists first delete
        if (file2.exists()) {
            file2.delete();
        }
        file.renameTo(file2);
    }
    //</editor-fold>
}
