package impl.Structures;

public class WordToken extends Token {
    boolean isCapital=false;

    public WordToken(String word, String type, boolean isCapital, boolean changed) {
        super(word,type,changed);
        this.isCapital=isCapital;
    }
    public boolean isCapital() {
        return isCapital;
    }
}


