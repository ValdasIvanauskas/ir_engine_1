package impl.Structures;

import impl.Parse.StopWords;
import impl.Parse.Tokenizer;

import java.util.HashMap;
import java.util.Map;

//This class represent a document
public class Document {
    private long doc_ID;
    private String date;
    private String title;
    private String text;
    private DocInfo docInfo;
    private HashMap<String, Integer> terms;
    static private long id_counter = 0;

    static public HashMap<Long,String> LocalToCorpusDocsID_mapping = new HashMap();

    public Document(String doc_ID, String date, String title, String text) {
        this.doc_ID = this.id_counter;
        this.date = date;
        this.title = title;
        this.text = text;
        terms = new HashMap<String, Integer>();
        LocalToCorpusDocsID_mapping.put(this.doc_ID, doc_ID);
        this.id_counter++;
    }

    public Document(String doc_ID, String text) {
        this.doc_ID = this.id_counter;
        this.text = text;
        terms = new HashMap<>();
        LocalToCorpusDocsID_mapping.put(this.doc_ID, doc_ID);
        this.id_counter++;
    }

    public long getDoc_ID() {
        return doc_ID;
    }

    public String getDate() {
        return date;
    }

    public String getTitle() {
        return title;
    }

    public String getText() {
        return text;
    }

    public HashMap<String, Integer> getTermsOfDocument() {
        return terms;
    }

    /**
     * Adding a term to this document checks if the word is already exist in this document in
     * capital or not capital form and filters words already at its level
     * @param term
     */
    public void addTerm(String term) {
        String lowerTerm = term.toLowerCase();
        String upperTerm = term.toUpperCase();

        //Stop word can be send to the document form an entity, filter them
        if (!StopWords.isStopWord(term, false)) {
            if(term.isEmpty())
                System.out.println(this.doc_ID + LocalToCorpusDocsID_mapping.get(this.doc_ID));
            if (Tokenizer.stemming) {
                lowerTerm = Tokenizer.stemmer.stem(term).toLowerCase();
                upperTerm = Tokenizer.stemmer.stem(term.toLowerCase()).toUpperCase();
            }
            //check if the current word already exist in this document in any form
            if (Character.isUpperCase(term.charAt(0))) {
                if (terms.containsKey(lowerTerm)) {
                    terms.put(lowerTerm, terms.get(lowerTerm) + 1);
                } else if (terms.containsKey(upperTerm)) {
                    terms.put(upperTerm, terms.get(upperTerm) + 1);
                } else {
                    terms.put(upperTerm, 1);
                }
            } else {
                if (terms.containsKey(upperTerm) && !lowerTerm.equals(upperTerm)) {
                    terms.put(lowerTerm, terms.get(upperTerm) + 1);
                    terms.remove(upperTerm);
                } else if (terms.containsKey(lowerTerm)) {
                    terms.put(lowerTerm, terms.get(lowerTerm) + 1);
                } else {
                    terms.put(lowerTerm, 1);
                }
            }
        }
    }

    public DocInfo getDocInfo() {
        return docInfo;
    }

    /**
     * Delete all this document text to free memory
     * Called by the parser
     */
    public void deleteText() {
        this.text = null;
        int unique_terms = terms.size();
        int max_tf = 0;
        int sum = 0;
        if (unique_terms > 0) {
            for (Map.Entry<String, Integer> stringIntegerEntry : terms.entrySet()) {
                String term = stringIntegerEntry.getKey();
                if (!term.contains(" ") && !Character.isDigit(term.charAt(0))){
                    int value = stringIntegerEntry.getValue();
                    if (value >max_tf)
                        max_tf=value;
                    sum+=value;
                }
            }
        }
        docInfo = new DocInfo(max_tf, unique_terms, sum, Document.LocalToCorpusDocsID_mapping.remove(this.doc_ID));
    }
}