package impl.Structures;

public class TermInfo {
    private int documentFrequency;
    private int totalTermFrequency;
    private int lineNumberInPosting;

    public TermInfo(int documentFrequency, int totalTermFrequency, int lineNumberInPosting) {
        this.documentFrequency = documentFrequency;
        this.totalTermFrequency = totalTermFrequency;
        this.lineNumberInPosting = lineNumberInPosting;
    }

    public int getDocumentFrequency() {
        return documentFrequency;
    }

    public void setDocumentFrequency(int documentFrequency) {
        this.documentFrequency = documentFrequency;
    }

    public int getLineNumberInPosting() {
        return lineNumberInPosting;
    }

    public void setLineNumberInPosting(int lineNumberInPosting) {
        this.lineNumberInPosting = lineNumberInPosting;
    }

    public int getTotalTermFrequency() {
        return totalTermFrequency;
    }

    @Override
    public String toString() {
        return documentFrequency + "\t" + totalTermFrequency + "\t" + lineNumberInPosting +
                '\n';
    }
}
