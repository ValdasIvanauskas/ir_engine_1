package impl.Structures;

public abstract class Token {
    private String content;
    private String type;
    private boolean changed;

    public Token(String content, String type, boolean changed) {
        this.content = content;
        this.type = type;
        this.changed = changed;
    }

    public String getContent() {
        return content;
    }

    public String getType() {
        return type;
    }

    public boolean isChanged() {
        return changed;
    }
}
