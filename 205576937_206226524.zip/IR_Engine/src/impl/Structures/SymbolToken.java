package impl.Structures;

public class SymbolToken extends Token {
    public SymbolToken(String content, String type, boolean changed) {
        super(content, type, changed);
    }
}
