package impl.Structures;

//This Class represent a doc information that will be write to the doc dictionary
public class DocInfo {
    private int max_tf;
    private int unique_terms;
    private int doc_length;
    private String corpus_docNo;

    public DocInfo(int max_tf, int unique_terms, int doc_length, String corpus_docNo) {
        this.max_tf = max_tf;
        this.unique_terms = unique_terms;
        this.doc_length = doc_length;
        this.corpus_docNo = corpus_docNo;
    }

    public int getMax_tf() {
        return max_tf;
    }

    public int getUnique_terms() {
        return unique_terms;
    }

    public String getCorpus_docNo() {
        return corpus_docNo;
    }

    public void decreaseUnique_terms(){
        this.unique_terms--;
    }

    public void decreaseDoc_length(int frequency){
        this.unique_terms-=frequency;
    }

    @Override
    public String toString() {
        return max_tf +
                "\t" + unique_terms +
                "\t" + doc_length +
                "\t" + corpus_docNo +
                '\n';
    }
}