package impl.Structures;

public class NumberToken extends Token {
    public NumberToken(String word, String type, boolean changed) {
        super(word,type,changed);
    }
}
