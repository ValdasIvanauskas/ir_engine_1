package impl.ReadFile;

import impl.Parse.StopWords;
import impl.Structures.Document;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class ReadFile {
    final Pattern DOC_START_PATTERN = Pattern.compile("<DOC>(.+?)</DOC>", Pattern.DOTALL);
    final Pattern DOC_ID_PATTERN = Pattern.compile("<DOCNO>(.+?)</DOCNO>", Pattern.DOTALL);
    final Pattern DOC_DATE_PATTERN = Pattern.compile("<DATE1>(.+?)</DATE1>|<DATE>(.+?)</DATE>", Pattern.DOTALL);
    final Pattern DOC_TITLE_PATTERN = Pattern.compile("<TI>(.+?)</TI>|<HEADLINE>(.+?)</HEADLINE|<SECTION>(.+?)</SECTION>", Pattern.DOTALL);
    final Pattern DOC_TEXT_PATTERN = Pattern.compile("<TEXT>(.+?)</TEXT>", Pattern.DOTALL);

    private List<Document> allDocuments;
    private List<File> filesInPath;
    private int batchSize;

    /**
     *Reading x files from the given path (x= batchSize)
     * @param path
     * @param batchSize
     * @throws IOException
     */
    public ReadFile(String path, int batchSize) throws IOException {
        this.batchSize = batchSize;
        filesInPath = Files.walk(Paths.get(path))
                .filter(Files::isRegularFile)
                .map(Path::toFile)
                .collect(Collectors.toList());
        //If stop word file
        for (File file : filesInPath) {
            if (file.getName().contains("stop")) {
                readContent(file);
                break;
            }
        }
        allDocuments = new ArrayList<>();
    }


    /**
     * Send to readContent method x files in the filesInPath list (x=batchSize)
     * Uses Files.walk method
     * @return True after finishing reading x files
     * @throws IOException
     */
    public boolean listAllFiles() throws IOException {
        if (filesInPath.isEmpty())
            return false;
        allDocuments.clear();
        for (int i = 0; i < this.batchSize && !filesInPath.isEmpty(); i++) {
            readContent(filesInPath.remove(0));
        }
        return true;
    }

    /**
     * Read all the content from given file to a string called by the ReadFile method
     * @param file
     * @throws IOException
     */
    public void readContent(File file) throws IOException {
        StringBuilder stringBuilder = new StringBuilder();
        //System.out.println("read file " + file.getCanonicalPath() );
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String strLine;
            // Read lines from the file, returns null when end of stream
            // is reached
            while ((strLine = br.readLine()) != null) {
                stringBuilder.append(strLine + " ");
            }
            if (file.getName().contains("stop")) {
                toStopWord(stringBuilder.toString());
            } else {
                toDocument(stringBuilder.toString());
            }
        }
    }

    /**
     * Add all the terms in the file "stop words" to the StopWord class
     * @param content
     */
    private void toStopWord(String content) {
        List<String> list = new ArrayList<String>();
        int pos = 0, end;
        while ((end = content.indexOf(' ', pos)) >= 0) {
            list.add(content.substring(pos, end));
            pos = end + 1;
        }
        if (pos < content.length()) {
            list.add(content.substring(pos));
        }
        StopWords.setStopWord(list);
    }

    /**
     * Extract from the text, base on the relent tags and create a document with all the information
     * Doc: ID, Date, Title, Text
     * @param content
     */
    private void toDocument(String content) {
        List<Document> documents = new ArrayList<>();
        String newDoc = new String();
        Matcher matcher = DOC_START_PATTERN.matcher(content);
        while (matcher.find()) {
            newDoc = matcher.group(1);
            Matcher matcherDocId = DOC_ID_PATTERN.matcher(newDoc);
            matcherDocId.find();
            Matcher matcherDocDate = DOC_DATE_PATTERN.matcher(newDoc);
            matcherDocDate.find();
            Matcher matcherDocTitle = DOC_TITLE_PATTERN.matcher(newDoc);
            matcherDocTitle.find();
            Matcher matcherDocText = DOC_TEXT_PATTERN.matcher(newDoc);
            matcherDocText.find();
            try {
                documents.add(new Document(matcherDocId.group(1), matcherDocDate.group(1), matcherDocTitle.group(1), matcherDocText.group(1)));
            } catch (Exception e) {
                try {
                    documents.add(new Document(matcherDocId.group(1), matcherDocText.group(1)));
                } catch (Exception ec) {
                }
            }

        }
        allDocuments.addAll(documents);
    }

    public List<Document> getAllDocuments() {
        return allDocuments;
    }
}