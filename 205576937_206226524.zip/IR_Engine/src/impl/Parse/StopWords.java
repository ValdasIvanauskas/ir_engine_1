package impl.Parse;
import java.util.HashSet;
import java.util.List;

public class StopWords {
    //<editor-fold desc="Static Variables">
    static private HashSet<String> stopWord;
    static private HashSet<String> excludeWords;
    static {
        excludeWords = new HashSet<>();
        stopWord = new HashSet<>();
    }
    //</editor-fold>

    //<editor-fold desc="Static setters">
    public static void setStopWord(List<String> stopWordList) {
        stopWord.addAll(stopWordList);
    }
    //Set the stop words that we would like not to remove in some point (like "between" and "and")
    public static void setExcludeWords(List<String> excludeWordList) {
        excludeWords.addAll(excludeWordList);
    }
    //</editor-fold>

    //<editor-fold desc="Stop word checker">
    public static boolean isStopWord(String word, boolean useExclude) {
        if (useExclude && excludeWords.contains(word.toLowerCase().trim())) {
            return false;
        } else
            return stopWord.contains(word.toLowerCase().trim());
    }
    //</editor-fold>
}
