package impl.Parse;
import impl.Structures.*;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Parse {
    //<editor-fold desc="Local variables">
    private static final List<String> excludeWordsList = Collections.unmodifiableList(Arrays.asList("and", "between"));
    //</editor-fold>

    //<editor-fold desc="Constructors">
    public Parse(boolean stemming) {
        Tokenizer.setStemming(stemming);
    }
    //</editor-fold>

    //<editor-fold desc="Main parsing method">

    /**
     * Main parsing method which sends each term in the document to a relevant function based on its type
     * called by parse method
     * @param doc
     */
    public void parse(Document doc) {
        //Don't remove her the words "and" and "between"
        StopWords.setExcludeWords(excludeWordsList);
        List<Token> tokens = Tokenizer.tokenize(doc.getText());
        int sizeTokens = tokens.size();
        for (int i = 0; i < sizeTokens; i++) {
            Token firstToken = tokens.get(i);
            //if the word is stop word (not including and&between) continue
            if (StopWords.isStopWord(firstToken.getContent(), true) && !((WordToken) firstToken).isCapital())
                continue;
            String firstTokenType = firstToken.getType();
            //NumberToken
            if (firstToken instanceof NumberToken) {
                i = handleNumberFirstToken(doc, tokens, sizeTokens, i, firstToken, firstTokenType);
            //WordToken
            } else if (firstToken instanceof WordToken) {
                i = handleWordFirstToken(doc, tokens, sizeTokens, i, (WordToken) firstToken, firstTokenType);
             //SymbolToken
            } else if (firstToken instanceof SymbolToken) {
                i = handleSymbolFirstToken(doc, tokens, sizeTokens, i, firstToken);
            }
        }
        //Delete for this doc his text
        doc.deleteText();
    }
    //</editor-fold>

    //<editor-fold desc="Handle tokens by type">

    /**
     * Knowing the first token is Symbol check if the next terms and suit to ant pattern
     * called by parse method
     * @param doc
     * @param tokens
     * @param sizeTokens
     * @param i
     * @param firstToken
     * @return the index of the next term that need to be handle
     */
    private int handleSymbolFirstToken(Document doc, List<Token> tokens, int sizeTokens, int i, Token firstToken) {
        //first is $number kind
        if (firstToken.getType().equals("PRICE")) {
            //if there is any token after that
            if (i + 1 < sizeTokens) {
                Token secondToken = tokens.get(i + 1);
                //check if second token is money numeral type ($50 million)
                if (secondToken.getType().equals("MONEY_NUMERAL")) {
                    doc.addTerm(priceNumberNumeralProcessor(firstToken, secondToken));
                    //skip these term in the parse
                    i++;
                } else {
                    //if the second term isn't fit just process the first token
                    doc.addTerm(priceNumberProcessor(firstToken));
                }
            } else {
                //if there isn't second term process the first token
                doc.addTerm(priceNumberProcessor(firstToken));
            }
            //first is number% kind
        } else if (firstToken.getType().equals("PERCENT")) {
            //send to processor
            doc.addTerm(symbolPercentNumberProcessor(firstToken));
        }
        //return from which index the parse need to continue
        return i;
    }

    /**
     * Knowing the first token is Word type check if the next terms and suit to ant pattern
     * called by parse method
     * @param doc
     * @param tokens
     * @param sizeTokens
     * @param i
     * @param firstToken
     * @param firstTokenType
     * @return the index of the next term that need to be handle
     */
    private int handleWordFirstToken(Document doc, List<Token> tokens, int sizeTokens, int i, WordToken firstToken, String firstTokenType) {
        //If the given token is capital and hasn't changed (it didn't have any punctuation) it can be an entity
        if (firstToken.isCapital() && !firstToken.isChanged()) {
            Integer j = isCapitalSequence(doc, tokens, sizeTokens, i, firstToken);
            //if this entity return to th parse the next index that need to process
            if (j != null) return j;
        }
        //If the token is stop word (not include and&between) and its not fit to some pattern (like month-MAY) skip
        if (StopWords.isStopWord(firstToken.getContent(), true) && firstTokenType.equals("SIMPLE"))
            return i;
        //The token is "BETWEEN", check the pattern "between x AND y"
        if (firstTokenType.equals("BETWEEN") && !firstToken.isChanged()) {
            if (i + 3 < sizeTokens) {
                Token secondToken = tokens.get(i + 1);
                if (secondToken instanceof NumberToken) {
                    String thirdTokenType = tokens.get(i + 2).getType();
                    if (thirdTokenType.equals("AND")) {
                        Token fourthToken = tokens.get(i + 3);
                        if (fourthToken instanceof NumberToken) {
                            //It fit to the pattern, add ad a range
                            i = addRangeToDoc(doc, i, secondToken, fourthToken);
                        } else {
                            //add only x as a number, don't add "between" and "and"
                            doc.addTerm(numberProcessor(secondToken));
                            i += 2;
                        }
                       //"between x..." return to the parse to process x
                    } else {
                        i++;
                    }
                }
            }
            //The token is MONTH type, check if MONTH-DAY or MONTH-YEAR
        } else if (firstTokenType.equals("MONTH") && !firstToken.isChanged()) {
            if (i + 1 < sizeTokens) {
                Token secondToken = tokens.get(i + 1);
                //Check if the second token is a valid date
                if (isValidDayDate(secondToken)) {
                    i = addNumberDateMonthDayToDoc(doc, i, secondToken, firstToken);
                 //Check if the second token is a valid year
                } else if (isValidYear(secondToken)) {
                    i = addMonthWordYearToDoc(doc, i, firstToken, secondToken);
                 //not fit to any pattern, just add the token (stopWord will be check in the doc)
                } else {
                    doc.addTerm(firstToken.getContent());
                }
                //There isn't second token, just add the term (stopWord will be check in the doc)
            } else {
                doc.addTerm(firstToken.getContent());
            }
            //Not fit to any pattern, just add the token
        } else {
            doc.addTerm(firstToken.getContent());
        }
        //return from which index the parse need to continue
        return i;
    }

    /**
     * Knowing the first token is Number type check if the next terms and suit to ant pattern
     * @param doc
     * @param tokens
     * @param sizeTokens
     * @param i
     * @param firstToken
     * @param firstTokenType
     * @return the index of the next term that need to be handle
     */
    private int handleNumberFirstToken(Document doc, List<Token> tokens, int sizeTokens, int i, Token firstToken, String firstTokenType) {
        //if the token hasn't changed (it didn't have any punctuation) and has a token after it - search for pattern
        if (!firstToken.isChanged() && (i + 1 < sizeTokens)) {
            Token secondToken = tokens.get(i + 1);
            String secondTokenType = secondToken.getType();
            //Second term is a word
            if (secondToken instanceof WordToken) {
                //The second term is percent type (8 PERCENTAGE)
                if (secondTokenType.equals("PERCENTAGE")) {
                    i = addNumberPercentageToDoc(doc, i, firstToken);
                 //The second term is dollar type (8 Dollars)
                } else if (secondTokenType.equals("DOLLAR")) {
                    i = addNumberMoneyDollarToDoc(doc, i, firstToken);
                } else {
                    //Patterns for simple or decimal numbers only
                    if (!firstTokenType.equals("FRACTION")) {
                        //The second term is number numeral (8 Million)
                        if (secondTokenType.equals("NUMBER_NUMERAL")) {
                            i = addNumberNumeralToDoc(doc, i, firstToken, secondToken);
                            //he second term is money numeral (8bn)
                        } else if (secondTokenType.equals("MONEY_NUMERAL")) {
                            i = handleMoneyNumeralSecond(doc, tokens, sizeTokens, i, firstToken, secondToken);
                            //Patterns for simple numbers only
                        } else if (firstTokenType.equals("SIMPLE")) {
                            //Check for the patterN DAY-MONTH
                            if (isValidDayDate(firstToken) && secondTokenType.equals("MONTH")) {
                                i = addNumberDateMonthDayToDoc(doc, i, firstToken, secondToken);
                            } else {
                                doc.addTerm(numberProcessor(firstToken));
                            }
                        } else {
                            doc.addTerm(numberProcessor(firstToken));
                        }
                    } else {
                        doc.addTerm(numberProcessor(firstToken));
                    }
                }
             //Second term is a number as well
            } else if (secondToken instanceof NumberToken) {
                //Simple number and fraction (8 3/4)
                if (firstTokenType.equals("SIMPLE") && secondTokenType.equals("FRACTION")) {
                    if (i + 2 < sizeTokens) {
                        //If there is a DOLLAR after that send to price process function
                        if (tokens.get(i + 2).getType().equals("DOLLAR")) {
                            i = addNumberFractionDollarToDoc(doc, i, firstToken, secondToken);
                            //If the simple number is under 1000, by the parse rules both of the token need to be process together
                        } else if (isUnderThousand(firstToken)) {
                            i = addNumberFractionToDoc(doc, i, firstToken, secondToken);
                            //else, send only th first number to process, and the parse will handle the secone token in the next iteration
                        } else {
                            doc.addTerm(numberProcessor(firstToken));
                        }
                        //If the simple number is under 1000, by the parse rules both of the token need to be process together
                    } else if (isUnderThousand(firstToken)) {
                        i = addNumberFractionToDoc(doc, i, firstToken, secondToken);
                        //else, send only th first number to process, and the parse will handle the second token in the next iteration
                    } else {
                        doc.addTerm(numberProcessor(firstToken));
                    }
                    //Second token is not simple or fraction (decimal)
                } else {
                    doc.addTerm(numberProcessor(firstToken));
                }
                //Second token in not word or number
            } else {
                doc.addTerm(numberProcessor(firstToken));
            }
            //The number have been change or there isn't token after him, just Process him
        } else {
            doc.addTerm(numberProcessor(firstToken));
        }
        return i;
    }

    /**
     * Transforms a sequence of terms that are found to fit to money numeral pattern into a uniform expression
     * Patterns: Price m Dollars, Price bn Dollars, Price billion U.S. dollars, Price million U.S. dollars, Price trillion U.S. dollars
     * Uniform expression: Price M Dollars
     * @param doc
     * @param tokens
     * @param sizeTokens
     * @param i
     * @param firstToken
     * @param secondToken
     * @return The index of the next term that need to be handle
     */
    private int handleMoneyNumeralSecond(Document doc, List<Token> tokens, int sizeTokens, int i, Token firstToken, Token secondToken) {
        //Check the third token
        if (i + 2 < sizeTokens) {
            //Check pattern "Price million dollars"
            Token thirdToken = tokens.get(i + 2);
            if (thirdToken.getType().equals("DOLLAR")) {
                doc.addTerm(numberMoneyNumeralProcessor(firstToken, secondToken));
                i += 2;
                //Check Pattern "Price million U.S. dollars"
            } else if (thirdToken.getContent().equals("US")) {
                if (i + 3 < sizeTokens) {
                    if (tokens.get(i + 3).getType().equals("DOLLAR")) {
                        doc.addTerm(numberMoneyNumeralProcessor(firstToken, secondToken));
                        i += 3;
                        //Not fit the pattern "Price million U.S. dollars", send both the number and the numeral to regular number processor
                    } else {
                        doc.addTerm(numberNumeralProcessor(firstToken, secondToken));
                        i += 1;
                    }
                }
                //Not fit for money numeral pattern, send both the number and the numeral to regular number processor
            } else {
                doc.addTerm(numberNumeralProcessor(firstToken, secondToken));
                i += 1;
            }
        }
        return i;
    }
    //</editor-fold>

    //<editor-fold desc="Add term to document by parsing rules">
    private int addMonthWordYearToDoc(Document doc, int i, Token firstToken, Token secondToken) {
        doc.addTerm(monthWordYearProcessor(firstToken, secondToken));
        i++;
        return i;
    }

    private int addRangeToDoc(Document doc, int i, Token secondToken, Token fourthToken) {
        //for w1-w2 add to the doc term: w1, w2, w1-w2
        doc.addTerm(betweenAndProcessor(secondToken, fourthToken));
        doc.addTerm(numberProcessor(secondToken));
        doc.addTerm(numberProcessor(fourthToken));
        i += 3;
        return i;
    }

    private int addNumberFractionToDoc(Document doc, int i, Token firstToken, Token secondToken) {
        doc.addTerm(numberFractionProcessor(firstToken, secondToken));
        i++;
        return i;
    }

    private int addNumberFractionDollarToDoc(Document doc, int i, Token firstToken, Token secondToken) {
        doc.addTerm(numberFractionDollarProcessor(firstToken, secondToken));
        i += 2;
        return i;
    }

    private int addNumberDateMonthDayToDoc(Document doc, int i, Token firstToken, Token secondToken) {
        doc.addTerm(numberDateMonthDayProcessor(firstToken, secondToken));
        i++;
        return i;
    }

    private int addNumberNumeralToDoc(Document doc, int i, Token firstToken, Token secondToken) {
        doc.addTerm(numberNumeralProcessor(firstToken, secondToken));
        i++;
        return i;
    }

    private int addNumberMoneyDollarToDoc(Document doc, int i, Token firstToken) {
        doc.addTerm(numberMoneyDollarProcessor(firstToken));
        i++;
        return i;
    }

    private int addNumberPercentageToDoc(Document doc, int i, Token firstToken) {
        doc.addTerm(numberPercentageProcessor(firstToken));
        i++;
        return i;
    }
    //</editor-fold>

    //<editor-fold desc="Processors for tokens by parse rules">

    /**
     * Create a uniform expression for simple an decimal numbers (for fraction no need any processing)
     * @param token
     * @return Uniform expression: 1.2M, 1.2B, 1.2K and if smaller then 1000 keep it like that
     */
    private String numberProcessor(Token token) {
        boolean isSimple = token.getType().equals("SIMPLE");
        boolean isDecimal = token.getType().equals("DECIMAL");
        if (isDecimal || isSimple) {
            double number = Double.valueOf(token.getContent());
            double dividedNumber;
            char kmb = '\0';
            if (number >= 1000000000) {
                dividedNumber = number / 1000000000;
                kmb = 'B';
            } else if (number >= 1000000) {
                dividedNumber = number / 1000000;
                kmb = 'M';
            } else if (number >= 1000) {
                dividedNumber = number / 1000;
                kmb = 'K';
            } else {
                dividedNumber = number;
            }
            NumberFormat nf = new DecimalFormat("##.###");
            String s;
            if (kmb == '\0')
                s = nf.format(dividedNumber);
            else
                s = nf.format(dividedNumber) + "" + kmb;
            return s;
        }
        // Its FRACTION number
        else
            return token.getContent();
    }

    /**
     * Create a uniform expression for simple number and fraction (8 4/3)
     * @param simpleNumber
     * @param fractionNumber
     * @return Uniform expression: number fraction (8 3/4)
     */
    private String numberFractionProcessor(Token simpleNumber, Token fractionNumber) {
        return simpleNumber.getContent() + " " + fractionNumber.getContent();
    }

    /**
     * Create a uniform expression for simple number and fraction that have been fit to money pattern
     * @param simpleNumber
     * @param fractionNumber
     * @return Uniform expression: number fraction Dollars (8 3/4 Dollars)
     */
    private String numberFractionDollarProcessor(Token simpleNumber, Token fractionNumber) {
        return simpleNumber.getContent() + " " + fractionNumber.getContent() + " Dollars";
    }

    /**
     * Create a uniform expression for price with numeral which have been fit to price pattern
     * Converts from any numeral to million
     * @param priceNumber
     * @param moneyNumeral
     * @return Uniform expression: "number M Dollars"
     */
    private String priceNumberNumeralProcessor(Token priceNumber, Token moneyNumeral) {
        String content = priceNumber.getContent();
        double value;
        if(content.charAt(0) == '$') {
            value = Double.valueOf(content.substring(1));
        }
        else{
            value = Double.valueOf(content.substring(0,content.length()-1));
        }
        if (moneyNumeral.getContent().equals("bn") || moneyNumeral.getContent().equals("billion")) {
            value *= 1000;
        } else if (moneyNumeral.getContent().equals("trillion")) {
            value *= 1000000;
        }
        return value + " M Dollars";
    }

    /**
     *Create a uniform expression for $price
     * @param priceNumber
     * @return Uniform expression: "number M dollars" for number that bigger than million, otherwise "number Dollars"
     */
    private String priceNumberProcessor(Token priceNumber) {
        //Remove $
        String content = priceNumber.getContent();
        String substring;
        if(content.charAt(0) == '$') {
            substring =  content.substring(1);
        }
        else{
            substring = content.substring(0,content.length()-1);
        }
        //If the number is fraction just add Dollars
        if(CONFIG_CONSTANTS.FRACTION.matcher(substring).matches()){
            return substring + " Dollars";
        }
        double value = Double.valueOf(substring);
        if (value >= 1000000) {
            return value / 1000000 + " M Dollars";
        } else {
            return value + " Dollars";
        }
    }

    /**
     * Create a uniform expression for number%
     * @param percentNumber
     * @return Uniform expression: number%
     */
    private String symbolPercentNumberProcessor(Token percentNumber) {
        String content = percentNumber.getContent();
        if(content.charAt(0) == '%') {
            content = content.substring(1) + "%";
        }
        return content;
    }

    /**
     * Create a uniform expression for number numeral, number with length numeral and number with weigh numeral
     * @param number
     * @param numeral
     * @return Uniform expression:
     * Numbers - NUMBER B/M/K
     * Length - converter to meters NUMBER Mtr
     * Weigh - convert to kilograms NUMBER Kg
     */
    private String numberNumeralProcessor(Token number, Token numeral) {
        String numeralContent = numeral.getContent().toLowerCase();
        if (CONFIG_CONSTANTS.NUMBER_NUMERALS_MAPPING.containsKey(numeralContent))
            return number.getContent() + CONFIG_CONSTANTS.NUMBER_NUMERALS_MAPPING.get(numeralContent);
        else if(CONFIG_CONSTANTS.LENGTH_NUMERALS_MAPPING.containsKey(numeralContent))
            return lengthProcessor(number, CONFIG_CONSTANTS.LENGTH_NUMERALS_MAPPING.get(numeralContent)) + "Mtr";
        else
            return weightProcessor(number, CONFIG_CONSTANTS.WEIGHT_NUMERALS_MAPPING.get(numeralContent)) + "Kg";
    }

    /**
     * Convert numbers that fit to length to meters
     * @param token
     * @param lengthSize
     * @return The fix number n meters
     */
    private String lengthProcessor(Token token, char lengthSize) {
        double number;
        if (token.getType().equals("FRACTION")) {
            String[] numbers = token.getContent().split("/");
            number = Double.valueOf(numbers[0]) / Double.valueOf(numbers[1]);
        } else {
            number = Double.valueOf(token.getContent());
        }
        double dividedNumber;
        if (lengthSize == 'K') {
            dividedNumber = number * 1000;
        } else if (lengthSize == 'C') {
            dividedNumber = number / 1000;
        } else {
            dividedNumber = number;
        }
        NumberFormat nf = new DecimalFormat("##.###");
        String s;
        s = nf.format(dividedNumber);
        return s;
    }

    /**
     * Convert numbers that fit to length to kilograms
     * @param token
     * @param weightSize
     * @return The fix number in kilograms
     */
    private String weightProcessor(Token token, char weightSize) {
        double number;
        if (token.getType().equals("FRACTION")) {
            String[] numbers = token.getContent().split("/");
            number = Double.valueOf(numbers[0]) / Double.valueOf(numbers[1]);
        } else {
            number = Double.valueOf(token.getContent());
        }
        double dividedNumber;
        if (weightSize == 'T') {
            dividedNumber = number * 1000;
        } else if (weightSize == 'G') {
            dividedNumber = number / 1000;
        } else {
            dividedNumber = number;
        }
        NumberFormat nf = new DecimalFormat("##.###");
        String s;
        s = nf.format(dividedNumber);
        return s;
    }

    /**
     * Create a uniform expression for number who fit to percent pattern
     * @param number
     * @return Uniform expression: number%
     */
    private String numberPercentageProcessor(Token number) {
        return number.getContent() + "%";
    }

    /**
     * Create a uniform expression for number with numeral which pit tp price pattern
     * @param number
     * @param numeral
     * @return Uniform expression: convert all the number to million "number M Dollars"
     */
    private String numberMoneyNumeralProcessor(Token number, Token numeral) {
        double value = Double.valueOf(number.getContent());
        if (numeral.getContent().equals("bn") || numeral.getContent().equals("billion")) {
            return value * 1000 + " M Dollars";
        } else if (numeral.getContent().equals("trillion")) {
            return value * 1000000 + " M Dollars";
        }
        return value + " M Dollars";
    }

    /**
     * Create a uniform expression for numbers that fir to price pattern
     * @param number
     * @return Uniform expression: if the number bigger then 1000 convert to "number M Dollars" , else "number Dollars"
     */
    private String numberMoneyDollarProcessor(Token number) {
        if (number.getType().equals("FRACTION")) {
            return number.getContent() + " Dollars";
        }
        double numberValue = Double.valueOf(number.getContent());
        if (numberValue < 1000000) {
            return numberValue + " Dollars";
        } else {
            numberValue = numberValue / 1000000;
            return numberValue + " M Dollars";
        }
    }

    /**
     * Create a uniform expression for day month pattern
     * The method called after that the day has been validated
     * @param number
     * @param month
     * @return Uniform expression: MM-DD
     */
    private String numberDateMonthDayProcessor(Token number, Token month) {
        Long numberContent = Long.valueOf(number.getContent());
        if (numberContent < 10)
            return CONFIG_CONSTANTS.MONTH_TO_MM_MAPPING.get(month.getContent().toLowerCase()) + "-" + "0" + numberContent;
        return CONFIG_CONSTANTS.MONTH_TO_MM_MAPPING.get(month.getContent().toLowerCase()) + "-" + numberContent;
    }

    /**
     * Create a uniform expression for year month pattern
     * The method called after that the year has been validated
     * @param month
     * @param number
     * @return
     */
    private String monthWordYearProcessor(Token month, Token number) {
        Long numberContent = Long.valueOf(number.getContent());
        if (numberContent < 100)
            return "00" + numberContent + "-" + CONFIG_CONSTANTS.MONTH_TO_MM_MAPPING.get(month.getContent().toLowerCase());
        else if (numberContent < 1000)
            return "0" + numberContent + "-" + CONFIG_CONSTANTS.MONTH_TO_MM_MAPPING.get(month.getContent().toLowerCase());
        return numberContent + "-" + CONFIG_CONSTANTS.MONTH_TO_MM_MAPPING.get(month.getContent().toLowerCase());
    }

    private String betweenAndProcessor(Token number1, Token number2) {
        return number1.getContent() + "-" + number2.getContent();
    }
    //</editor-fold>

    //<editor-fold desc="Private validation of rules">

    /**
     * Check if the given number is valid date
     * @param number
     * @return if the given number is between 1 to 31
     */
    private boolean isValidDayDate(Token number) {
        String content = number.getContent();
        if (number instanceof NumberToken && number.getType().equals("SIMPLE") && content.length() <= 2) {
            Long value = Long.valueOf(content);
            return (value > 0 && value <= 31);
        }
        return false;
    }

    /**
     * Check if the given number is valid year
     * @param number
     * @return if the given number is between 32 to 9999
     */
    private boolean isValidYear(Token number) {
        String content = number.getContent();
        if (number instanceof NumberToken && number.getType().equals("SIMPLE") && content.length() <= 4) {
            Long value = Long.valueOf(content);
            return (value <= 9999 && value >= 32);
        }
        return false;
    }

    /**
     * Find if there is a sequence of word that start with capital letter
     * If so it may be an entity and it add the entity as a term and also all adding all the tokens the make up the entity
     * @param doc
     * @param tokens
     * @param sizeTokens
     * @param i
     * @param firstToken
     * @return
     */
    private Integer isCapitalSequence(Document doc, List<Token> tokens, int sizeTokens, int i, WordToken firstToken) {
        List<WordToken> allTokens = new ArrayList<>();
        allTokens.add(firstToken);
        StringBuilder sb = new StringBuilder();
        sb.append(firstToken.getContent()).append(" ");
        int j = i + 1;
        WordToken nextToken;
        //Check if the next token is WORD, capital and didn't change (no punctuation was deleted)
        while (j < sizeTokens && tokens.get(j) instanceof WordToken && (nextToken = (WordToken) tokens.get(j)).isCapital()) {
            sb.append(nextToken.getContent()).append(" ");
            allTokens.add(nextToken);
            j++;
            if (nextToken.isChanged())
                break;
        }
        //Add all the token (except stop words) to the term list as well
        if (allTokens.size() > 1) {
            for (WordToken allToken : allTokens) {
                if (!StopWords.isStopWord(allToken.getContent(), false))
                    doc.addTerm(allToken.getContent());
            }
            doc.addTerm(sb.toString().trim());
            return j - 1;
        }
        //There isn't capital sequence
        return null;
    }

    private boolean isUnderThousand(Token simpleNumber) {
        return Long.valueOf(simpleNumber.getContent()) < 1000;
    }
    //</editor-fold>
}



