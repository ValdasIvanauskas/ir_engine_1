package impl.Parse;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.regex.Pattern;

public class CONFIG_CONSTANTS {
    //<editor-fold desc="Static Hash SETS">
    public static final HashSet<Character> INSIDE_PUNCTUATION = new HashSet<>(Arrays.asList('$','%','.', '!', '?', '&', '*', '#', '@', '"', '\''));
    public static final HashSet<Character> TAILING_PUNCTUATION = new HashSet<>(Arrays.asList('�','¥',',', '.', '!', '?', ')', '(', ']', '[', '&', '*', '{', '}', '_', '-', '#', '@', '<', '>', ':', ';', '|', '"', '\'', '`', '`', '+', '=', '\''));
    public static final HashSet<String> PERCENTAGE = new HashSet<>(Arrays.asList("percent", "percentage"));
    public static final HashSet<String> BETWEEN = new HashSet<>(Collections.singletonList("between"));
    public static final HashSet<String> AND = new HashSet<>(Collections.singletonList("and"));
    public static final HashSet<String> DOLLAR = new HashSet<>(Arrays.asList("dollars", "dollar"));
    public static final HashSet<String> MONEY_NUMERAL = new HashSet<>(Arrays.asList("million", "millions", "billion", "billions", "trillion", "trillions", "m", "bn"));
    public static final HashSet<String> NUMBER_NUMERAL = new HashSet<>(Arrays.asList("Thousand", "Million", "Billion"));
    public static final HashSet<Character> ALPHABET = new HashSet<>(Arrays.asList('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'o', 'n', 'p', 'q', 'r', 's', 't', 'u', 'v', 'x', 'y', 'z', 'w'));
    public static final HashSet<Character> SPLIT_PUNCTUATION = new HashSet<>(Arrays.asList(',', ')', '(', ']', '[', '{', '}', '<', '>', ':', ';', '|', '\\', '/', '+', '='));
    public static final HashSet<String> MONTH = new HashSet<>(Arrays.asList("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec",
            "january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"));
    //</editor-fold>

    //<editor-fold desc="REGEX Patterns">
    static final Pattern FRACTION = Pattern.compile("(\\d+)/(\\d+)");
    static final Pattern DECIMAL = Pattern.compile("^\\d*\\.\\d+|\\d+\\.\\d*$\n");
    static final Pattern NUMBER = Pattern.compile("[0-9]+");
    static final Pattern RANGE = Pattern.compile("[^-]+-+[^-]+-+[^-]+|[^-]+-+[^-]+");
    public static final Pattern PRICE = Pattern.compile("(\\$)(?:(\\d*\\.\\d+|\\d+\\.\\d*$|(\\d+)(?:\\/(\\d+)))|[0-9]+)|(?:(\\d*\\.\\d+|\\d+\\.\\d*$|(\\d+)(?:\\/(\\d+)))|[0-9]+)(\\$)");
    static final Pattern PERCENT = Pattern.compile("(?:(\\d*\\.\\d+|\\d+\\.\\d*$|(\\d+)(?:\\/(\\d+)))|[0-9]+)(\\%)|(\\%)(?:(\\d*\\.\\d+|\\d+\\.\\d*$|(\\d+)(?:\\/(\\d+)))|[0-9]+)");
    static final Pattern NUMBER_SHORT_NUMERAL = Pattern.compile("(?:(\\d*\\.\\d+|\\d+\\.\\d*$|(\\d+)(?:\\/(\\d+)))|[0-9]+)(bn|m)");
    //</editor-fold>

    //<editor-fold desc="Static Hash MAP">
    static final HashMap<String, String> NUMBER_NUMERALS_MAPPING = getNumberNumeralsMapping();
    static final HashMap<String, Character> LENGTH_NUMERALS_MAPPING = getLengthNumeralsMapping();
    static final HashMap<String, Character> WEIGHT_NUMERALS_MAPPING = getWeightNumeralsMapping();
    static final HashMap<String, String> MONTH_TO_MM_MAPPING = getMonthToMmMapping();
    //</editor-fold>

    //<editor-fold desc="HashMap constructors">
    private static HashMap<String, String> getNumberNumeralsMapping() {
        HashMap<String, String> NUMBER_NUMERALS_MAPPING = new HashMap<>();
        NUMBER_NUMERALS_MAPPING.put("thousand", "K");
        NUMBER_NUMERALS_MAPPING.put("million", "M");
        NUMBER_NUMERALS_MAPPING.put("billion", "B");
        NUMBER_NUMERALS_MAPPING.put("millions", "M");
        NUMBER_NUMERALS_MAPPING.put("billions", "B");
        NUMBER_NUMERALS_MAPPING.put("m", "K");
        NUMBER_NUMERALS_MAPPING.put("bn", "B");
        NUMBER_NUMERALS_MAPPING.put("trillion", "T");
        NUMBER_NUMERALS_MAPPING.put("trillions", "T");
        return NUMBER_NUMERALS_MAPPING;
    }

    private static HashMap<String, Character> getLengthNumeralsMapping() {
        HashMap<String, Character> LENGTH_NUMERALS_MAPPING = new HashMap<>();
        LENGTH_NUMERALS_MAPPING.put("kilometre", 'K');
        LENGTH_NUMERALS_MAPPING.put("kilometer", 'K');
        LENGTH_NUMERALS_MAPPING.put("kilometers", 'K');
        LENGTH_NUMERALS_MAPPING.put("kilometres", 'K');
        LENGTH_NUMERALS_MAPPING.put("metre", 'M');
        LENGTH_NUMERALS_MAPPING.put("meter", 'M');
        LENGTH_NUMERALS_MAPPING.put("metres", 'M');
        LENGTH_NUMERALS_MAPPING.put("meters", 'M');
        LENGTH_NUMERALS_MAPPING.put("centimeter", 'C');
        LENGTH_NUMERALS_MAPPING.put("centimetre", 'C');
        LENGTH_NUMERALS_MAPPING.put("centimeters", 'C');
        LENGTH_NUMERALS_MAPPING.put("centimetres", 'C');
        LENGTH_NUMERALS_MAPPING.put("cm", 'C');
        LENGTH_NUMERALS_MAPPING.put("km", 'K');
        return LENGTH_NUMERALS_MAPPING;
    }

    private static HashMap<String, Character> getWeightNumeralsMapping() {
        HashMap<String, Character> WEIGHT_NUMERALS_MAPPING = new HashMap<>();
        WEIGHT_NUMERALS_MAPPING.put("kilogram", 'K');
        WEIGHT_NUMERALS_MAPPING.put("kilogramme", 'K');
        WEIGHT_NUMERALS_MAPPING.put("kilogrammes", 'K');
        WEIGHT_NUMERALS_MAPPING.put("kilograms", 'K');
        WEIGHT_NUMERALS_MAPPING.put("kgs", 'K');
        WEIGHT_NUMERALS_MAPPING.put("gram", 'G');
        WEIGHT_NUMERALS_MAPPING.put("grams", 'G');
        WEIGHT_NUMERALS_MAPPING.put("ton", 'T');
        WEIGHT_NUMERALS_MAPPING.put("tons", 'T');
        WEIGHT_NUMERALS_MAPPING.put("tonne", 'T');
        WEIGHT_NUMERALS_MAPPING.put("tonnes", 'T');
        return WEIGHT_NUMERALS_MAPPING;
    }

    private static HashMap<String, String> getMonthToMmMapping() {
        HashMap<String, String> MONTH_TO_MM_MAPPING = new HashMap<>();
        MONTH_TO_MM_MAPPING.put("jan", "01");
        MONTH_TO_MM_MAPPING.put("feb", "02");
        MONTH_TO_MM_MAPPING.put("mar", "03");
        MONTH_TO_MM_MAPPING.put("apr", "04");
        MONTH_TO_MM_MAPPING.put("jun", "06");
        MONTH_TO_MM_MAPPING.put("jul", "07");
        MONTH_TO_MM_MAPPING.put("aug", "08");
        MONTH_TO_MM_MAPPING.put("sep", "09");
        MONTH_TO_MM_MAPPING.put("oct", "10");
        MONTH_TO_MM_MAPPING.put("nov", "11");
        MONTH_TO_MM_MAPPING.put("dec", "12");
        MONTH_TO_MM_MAPPING.put("january", "01");
        MONTH_TO_MM_MAPPING.put("february", "02");
        MONTH_TO_MM_MAPPING.put("march", "03");
        MONTH_TO_MM_MAPPING.put("april", "04");
        MONTH_TO_MM_MAPPING.put("may", "05");
        MONTH_TO_MM_MAPPING.put("june", "06");
        MONTH_TO_MM_MAPPING.put("july", "07");
        MONTH_TO_MM_MAPPING.put("august", "08");
        MONTH_TO_MM_MAPPING.put("september", "09");
        MONTH_TO_MM_MAPPING.put("october", "10");
        MONTH_TO_MM_MAPPING.put("november", "11");
        MONTH_TO_MM_MAPPING.put("december", "12");
        return MONTH_TO_MM_MAPPING;
    }
    //</editor-fold>
}
