package impl.Parse;

import impl.Structures.NumberToken;
import impl.Structures.SymbolToken;
import impl.Structures.Token;
import impl.Structures.WordToken;
import javafx.util.Pair;
import opennlp.tools.stemmer.PorterStemmer;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class Tokenizer {
    //<editor-fold desc="Local Variables">
    public static boolean stemming = false;
    public static PorterStemmer stemmer = new PorterStemmer();
    //</editor-fold>

    /**
     * Create from text a tokens that spitted by space
     * Called by the parser which have the document where the text is stored
     * @param text
     * @return list of tokens
     */
    public static List<Token> tokenize(String text) {
        List<Token> list = new ArrayList();
        int pos = 0, end;
        String[] splittedText = text.split(" ");
        for (String s : splittedText) {
            addWordToList(list, s.trim());
        }
        return list;
    }

    /**
     * For each token add an additional info: what kind his is, if is capital and if punctuation have been deleted from head or tail
     * Called by the tokenize for each token
     * @param list
     * @param word
     */
    private static void addWordToList(List<Token> list, String word) {
        boolean isUpper;
        //Remove punctuation from head and tail if needed
        Pair<String, Boolean> returnedWord = removeGeneralPunctuation(word);
        if (!returnedWord.getKey().isEmpty()) {
            //Check if is capital
            isUpper = Character.isUpperCase(returnedWord.getKey().charAt(0));
            //return with token type
            list.addAll(contentType(returnedWord.getKey(), isUpper, returnedWord.getValue()));
        }
    }

    /**
     * Check for each token if it from one of this types:
     * for number: SIMPLE, FRACTION, DECIMAL, PRICE, PERCENT
     * for word: send to wordContentType
     * Called by addWordToList method
     * @param word
     * @param isUpper
     * @param changed
     * @return list og terns with there info
     */
    private static List<Token> contentType(String word, boolean isUpper, boolean changed) {
        List<Token> tokens = new ArrayList<>();
        if (!CONFIG_CONSTANTS.ALPHABET.contains(word.charAt(0))) {
            numbrContentType(word, isUpper, changed, tokens);
        } else if (CONFIG_CONSTANTS.RANGE.matcher(word).matches()) {
            List<String> range = splitRange(word);
            if (range != null) {
                for (String s : range) {
                    if (!s.isEmpty())
                        tokens.addAll(contentType(s, Character.isUpperCase(s.charAt(0)), changed));
                }
                tokens.addAll(wordsContentTypes(word, isUpper, changed));
            }
        } else {
            tokens.addAll(wordsContentTypes(word, isUpper, changed));

        }
        return tokens;
    }

    /**
     * Check for each number token what his type from: SIMPLE, FRACTION, DECIMAL, PRICE, PERCENT
     * @param word
     * @param isUpper
     * @param changed
     * @param tokens
     */
    private static void numbrContentType(String word, boolean isUpper, boolean changed, List<Token> tokens) {
        if (CONFIG_CONSTANTS.NUMBER.matcher(word).matches()) {
            tokens.add(new NumberToken(word, "SIMPLE", changed));
        } else if (CONFIG_CONSTANTS.FRACTION.matcher(word).matches()) {
            tokens.add(new NumberToken(word, "FRACTION", changed));
        } else if (CONFIG_CONSTANTS.DECIMAL.matcher(word).matches()) {
            tokens.add(new NumberToken(word, "DECIMAL", changed));
        } else if (CONFIG_CONSTANTS.PRICE.matcher(word).matches()) {
            tokens.add(new SymbolToken(word, "PRICE", changed));
        } else if (CONFIG_CONSTANTS.PERCENT.matcher(word).matches()) {
            tokens.add(new SymbolToken(word, "PERCENT", changed));
        } else if (CONFIG_CONSTANTS.NUMBER_SHORT_NUMERAL.matcher(word.toLowerCase()).matches()) {
            String[] pair = word.toLowerCase().split("(?=[a-z])", 2);
            tokens.addAll(contentType(pair[0], isUpper, changed));
            tokens.addAll(contentType(pair[1], isUpper, changed));
        } else if (CONFIG_CONSTANTS.RANGE.matcher(word).matches()) {
            List<String> range = splitRange(word);
            if (range != null) {
                for (String s : range) {
                    if (!s.isEmpty())
                        tokens.addAll(contentType(s, Character.isUpperCase(s.charAt(0)), changed));
                }
                tokens.addAll(wordsContentTypes(word, isUpper, changed));
            }
        } else {
            tokens.addAll(wordsContentTypes(word, isUpper, changed));
        }
    }

    /**
     *Handling
     * @param word
     * @param isUpper
     * @param changed
     * @return
     */
    private static List<Token> wordsContentTypes(String word, boolean isUpper, boolean changed) {
        List<String> terms = removeWordPunctuation(word);
        if(terms.size()>1){
            List<Token> tokens = new ArrayList<>();
            for (String term : terms) {
                if (!term.isEmpty()) {
                    Pair<String, Boolean> returnedWord = removeGeneralPunctuation(term);
                    String wordKey = returnedWord.getKey();
                    if(!wordKey.isEmpty())
                        tokens.addAll(contentType(wordKey, Character.isUpperCase(wordKey.charAt(0)), true));
                }
            }
            return tokens;
        }
        else {
            List<Token> tokens = new ArrayList<>();
            for (String term : terms) {
                if (!term.isEmpty())
                    tokens.add(wordContentType(term, Character.isUpperCase(term.charAt(0)), changed));
            }
            return tokens;
        }
    }

    /**
     * Check for each word token what his type from: AND, BETWEEN, MONTH, PERCENTAGE, DOLLAR, MONEY_NUMERAL, NUMBER_NUMERAL
     * @param word
     * @param isUpper
     * @param changed
     * @return
     */
    private static Token wordContentType(String word, boolean isUpper, boolean changed) {
        String lowerWord = word.toLowerCase();
        if (CONFIG_CONSTANTS.AND.contains(lowerWord)) {
            return new WordToken(word, "AND", isUpper, changed);
        } else if (CONFIG_CONSTANTS.BETWEEN.contains(lowerWord)) {
            return new WordToken(word, "BETWEEN", isUpper, changed);
        } else if (CONFIG_CONSTANTS.MONTH.contains(lowerWord)) {
            return new WordToken(word, "MONTH", isUpper, changed);
        } else if (CONFIG_CONSTANTS.PERCENTAGE.contains(lowerWord)) {
            return new WordToken(word, "PERCENTAGE", isUpper, changed);
        } else if (CONFIG_CONSTANTS.DOLLAR.contains(lowerWord)) {
            return new WordToken(word, "DOLLAR", isUpper, changed);
        } else if (CONFIG_CONSTANTS.MONEY_NUMERAL.contains(word)) {
            return new WordToken(word, "MONEY_NUMERAL", isUpper, changed);
        } else if (CONFIG_CONSTANTS.NUMBER_NUMERAL.contains(word) || CONFIG_CONSTANTS.LENGTH_NUMERALS_MAPPING.containsKey(lowerWord) || CONFIG_CONSTANTS.WEIGHT_NUMERALS_MAPPING.containsKey(lowerWord)) {
            return new WordToken(word, "NUMBER_NUMERAL", isUpper, changed);
        } else {
            return new WordToken(word, "SIMPLE", isUpper, changed);
        }
    }

    /**
     * Removing punctuation from the start and the end of token (!!ali!sa#)
     * change the isChange for true
     * @param word
     * @return token without punctuation in the head and tail (ali!sa)
     */
    private static Pair<String, Boolean> removeGeneralPunctuation(String word) {
        String resultWord = word;
        boolean changed = false;
        //Remove all the punctuation that appear in the token's head
        while (resultWord.length() > 0 && CONFIG_CONSTANTS.TAILING_PUNCTUATION.contains(resultWord.charAt(0))) {
            resultWord = resultWord.substring(1);
        }
        //Remove all the punctuation that appear in the token's tail
        while (resultWord.length() > 0 && CONFIG_CONSTANTS.TAILING_PUNCTUATION.contains(resultWord.charAt(resultWord.length() - 1))) {
            resultWord = resultWord.substring(0, resultWord.length() - 1);
            changed = true;
        }
        return new Pair<>(resultWord.replaceAll(",", ""), changed);
    }

    /**
     * Removing punctuation form all the token form WORD type and replace them with space
     * @param word
     * @return token without punctuation
     */
    private static List<String> removeWordPunctuation(String word) {
        List<String> terms = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        //for each char in the token check if it split punctuation, if so create add the current string to the list and create a new one
        for (char c : word.toCharArray()) {
            if (CONFIG_CONSTANTS.SPLIT_PUNCTUATION.contains(c)) {
                terms.add(sb.toString());
                sb = new StringBuilder();
                continue;
            }
            //if the current char is not an inside punctuation add him to the current string
            if (!CONFIG_CONSTANTS.INSIDE_PUNCTUATION.contains(c))
                sb.append(c);
        }
        //Add the last string to the list
        terms.add(sb.toString());
        //For each term remove a general punctuation as well
        for (String term : terms) {
            removeGeneralPunctuation(term);
        }
        return terms;
    }

    /**
     * Create from one token that have hyphen two tokens by using splitByHyphen function
     * @param word
     * @return list with two token that have been splited by hyphen
     */
    private static List<String> splitRange(String word) {
        if (word.contains("-")) {
            return splitByHyphen(word, "-");
        } else if (word.contains("_")) {
            return splitByHyphen(word, "_");
        }
        return null;
    }

    /**
     * Split a token by - or _
     * called by splitRange
     * @param word
     * @param s
     * @return list with two token that have been splited by hyphen
     */
    private static List<String> splitByHyphen(String word, String s) {
        StringTokenizer tokenValue = new StringTokenizer(word, s);
        List<String> splitArray = new ArrayList<>();
        while (tokenValue.hasMoreTokens()) {
            splitArray.add(tokenValue.nextToken());
        }
        return splitArray;
    }

    public static void setStemming(boolean stemming) {
        Tokenizer.stemming = stemming;
    }

}