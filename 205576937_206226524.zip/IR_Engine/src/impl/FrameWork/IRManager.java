package impl.FrameWork;

import impl.Indexer.Indexer;
import impl.Parse.CONFIG_CONSTANTS;
import impl.Parse.Parse;
import impl.ReadFile.ReadFile;
import impl.Structures.DocInfo;
import impl.Structures.Document;
import impl.Structures.TermInfo;
import javafx.util.Pair;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class IRManager {
    //<editor-fold desc="Local Variables">
    private Map<String, TermInfo> termsDictionary;
    private Map<Long, DocInfo> docsDictionary;
    private String corpusPath;
    private String postingFilePath;
    private Long totalTime;
    private int docSize;
    private int termSize;
    //</editor-fold>

    //<editor-fold desc="GUI Functionality Methods">

    /**
     * A constructor for the IRmanager class which set the corpus's path and the posting file's path
     * @param corpusPath
     * @param postingFilePath
     */
    public IRManager(String corpusPath, String postingFilePath) {
        this.setCorpusPath(corpusPath);
        this.setPostingFilePath(postingFilePath);
    }

    /**
     * Starting the IR process which including calling to ReadFile, Parser and Index classes
     * Responsible for process which creating the all index and the relent files
     * Called after clicking the "start" button in the GUI
     * @param stemming
     * @throws IOException
     */
    public void startIR(boolean stemming) throws IOException {
        //Initialize variables
        long start = System.currentTimeMillis();
        ReadFile fileReader = new ReadFile(getCorpusPath(), 20);
        Parse parser = new Parse(stemming);
        Indexer indexer = new Indexer(stemming, getPostingFilePath());

        boolean b = fileReader.listAllFiles();
        //read batch of files, then parse each one of them and eventually merge them into one post file
        //The batch is defined in ReadFile Class
        readParseAndMergeBatch(fileReader, parser, indexer, b);

        //merge all the posting files that were created
        indexer.mergeAllFiles();

        //Create dictionary from the postfile
        setTermsDictionary(indexer.createDictionary());

        //Calculate the total time
        long stop = System.currentTimeMillis();
        setTotalTime(stop - start);

        //Set
        setDocsDictionary(indexer.getDocumentsDictionary());
        setDocSize(indexer.getDocumentsDictionarySize());
        setTermSize(indexer.getTermsDictionarySize());
        setTermsDictionary(indexer.getTermsDictionary());
    }

    /**
     * Responsible for deleting all the files that have been created during the process in the given path (postingFilePath)
     * and reset the local variables
     * Called after clicking the "reset" button in the GUI
     * @param postingFilePath
     * @return
     */
    public boolean resetIR(String postingFilePath) {
        try {
            Path path = Paths.get(postingFilePath);
            //remove all the files that have been created in the given path
            Files.newDirectoryStream(path).forEach(file -> {
                try {
                    Files.delete(file);
                } catch (IOException e) {
                    throw new UncheckedIOException(e);
                }
            });
            //Reset the local Var
            resetLocalVariables();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Responsible for load to the memory all the files in the given path (postingFilePath) and recreating the index respectively
     * Called after clicking the "load" button in the GUI
     * @param stemming
     * @param postingFilePath
     * @throws IOException
     */
    public void loadDictionary(boolean stemming, String postingFilePath) throws IOException {
        Indexer indexer = new Indexer(stemming, postingFilePath);
        //Set the term dictionary file to the new term dictionary
        setTermsDictionary(indexer.loadDictionary());
        //Set the document dictidonary file to the new document dictionary
        setDocsDictionary(indexer.getDocumentsDictionary());
        setTermSize(indexer.getTermsDictionarySize());
        setDocSize(indexer.getDocumentsDictionarySize());
    }
    //</editor-fold>

    //<editor-fold desc="Getters">
    public Map<String, TermInfo> getTermsDictionary() {return termsDictionary; }

    public Long getTotalTime() {return totalTime; }

    public int getDocSize() {return docSize; }

    public int getTermSize() {return termSize; }
    //</editor-fold>

    //<editor-fold desc="Private methods">
    /**
     * private function for startIR method
     * @param fileReader
     * @param parser
     * @param indexer
     * @param b
     * @throws IOException
     */
    private void readParseAndMergeBatch(ReadFile fileReader, Parse parser, Indexer indexer, boolean b) throws IOException {
        while (b) {
            List<Document> allDocuments = fileReader.getAllDocuments();
            //Parsing
            for(int i=0; i<allDocuments.size(); i++){
                parser.parse(allDocuments.get(i));
            }
            //Merging
            indexer.mergeAndSortTerms(allDocuments);
            //NextFiles
            b = fileReader.listAllFiles();
        }
    }

    /**
     * Reset the local variables for resetIR method
     */
    private void resetLocalVariables() {
        setTermsDictionary(null);
        setDocsDictionary(null);
        setTotalTime(Long.valueOf(0));
        setDocSize(0);
        setTermSize(0);
        System.gc();
    }

    private void setTermsDictionary(Map<String, TermInfo> termsDictionary) {
        this.termsDictionary = termsDictionary;
    }

    private Map<Long, DocInfo> getDocsDictionary() {
        return docsDictionary;
    }

    private void setDocsDictionary(Map<Long, DocInfo> docsDictionary) {
        this.docsDictionary = docsDictionary;
    }

    private String getCorpusPath() {
        return corpusPath;
    }

    private void setCorpusPath(String corpusPath) {
        this.corpusPath = corpusPath;
    }

    private String getPostingFilePath() {
        return postingFilePath;
    }

    private void setPostingFilePath(String postingFilePath) {
        this.postingFilePath = postingFilePath;
    }

    private void setTotalTime(Long totalTime) {
        this.totalTime = totalTime;
    }

    public void setDocSize(int docSize) {
        this.docSize = docSize;
    }

    public void setTermSize(int termSize) {
        this.termSize = termSize;
    }
    //</editor-fold>
}